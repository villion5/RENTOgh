"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function ConfirmPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = createClient()

  useEffect(() => {
    const confirmEmail = async () => {
      try {
        const { data: userData } = await supabase.auth.getUser()

        if (userData?.user) {
          const userType = userData.user.user_metadata?.user_type
          // Redirect to appropriate dashboard based on user type
          if (userType === "provider") {
            router.push("/provider/dashboard")
          } else {
            router.push("/renter")
          }
        } else {
          router.push("/auth/login")
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Confirmation failed")
        setIsLoading(false)
      }
    }

    confirmEmail()
  }, [supabase, router])

  if (error) {
    return (
      <div className="flex min-h-svh items-center justify-center p-6">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Confirmation Error</CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">Please try logging in again.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex min-h-svh items-center justify-center p-6">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Confirming Your Email</CardTitle>
          <CardDescription>Please wait while we verify your account...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    </div>
  )
}
