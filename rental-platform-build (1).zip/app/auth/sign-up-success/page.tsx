import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function SignUpSuccessPage() {
  return (
    <div className="flex min-h-svh w-full items-center justify-center p-6 md:p-10 bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="w-full max-w-md">
        <Card className="shadow-lg border-border">
          <CardHeader>
            <CardTitle className="text-2xl">Check Your Email</CardTitle>
            <CardDescription>We've sent you a confirmation email</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Please click the link in your email to confirm your account. This helps us verify your email address and
              keep your account secure.
            </p>
            <p className="text-sm text-muted-foreground">
              If you don't see the email in your inbox, check your spam folder.
            </p>
            <div className="space-y-2">
              <Link href="/" className="block">
                <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">Back to Home</Button>
              </Link>
              <Link href="/auth/login" className="block">
                <Button variant="outline" className="w-full bg-transparent">
                  Back to Login
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
