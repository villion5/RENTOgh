import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import SubAdminNav from "@/components/sub-admin/sub-admin-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function SubAdminVerificationPage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user || userData.user.user_metadata?.user_type !== "sub_admin") {
    redirect("/auth/login")
  }

  // Fetch pending and verified providers
  const { data: pendingProviders } = await supabase
    .from("providers")
    .select("*")
    .eq("is_verified", false)
    .order("created_at", { ascending: false })

  const { data: verifiedProviders } = await supabase
    .from("providers")
    .select("*")
    .eq("is_verified", true)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SubAdminNav user={userData.user} />

      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Provider Compliance Verification</h1>
          <p className="text-muted-foreground">Review and verify provider regulatory compliance</p>
        </div>

        {/* Pending Verifications */}
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-4">Pending Verification</h2>
          {pendingProviders && pendingProviders.length > 0 ? (
            <div className="space-y-4">
              {pendingProviders.map((provider) => (
                <Card key={provider.id} className="border-border">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{provider.business_name}</CardTitle>
                        <CardDescription>{provider.contact_person_name}</CardDescription>
                      </div>
                      <span className="px-3 py-1 rounded-full text-sm font-medium bg-yellow-500/20 text-yellow-700">
                        PENDING
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Property Type</p>
                        <p className="font-semibold capitalize">{provider.property_type}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Phone</p>
                        <p className="font-semibold">{provider.phone_number}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Applied</p>
                        <p className="font-semibold">{new Date(provider.created_at).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <Link href={`/sub-admin/verification/${provider.id}`}>
                      <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                        Review & Verify
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="border-border text-center py-12">
              <p className="text-muted-foreground">No pending verifications</p>
            </Card>
          )}
        </div>

        {/* Verified Providers */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Verified Providers</h2>
          {verifiedProviders && verifiedProviders.length > 0 ? (
            <div className="space-y-4">
              {verifiedProviders.slice(0, 10).map((provider) => (
                <Card key={provider.id} className="border-border">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{provider.business_name}</CardTitle>
                        <CardDescription>{provider.contact_person_name}</CardDescription>
                      </div>
                      <span className="px-3 py-1 rounded-full text-sm font-medium bg-green-500/20 text-green-700">
                        VERIFIED
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Property Type</p>
                        <p className="font-semibold capitalize">{provider.property_type}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Verified Date</p>
                        <p className="font-semibold">
                          {provider.verification_date
                            ? new Date(provider.verification_date).toLocaleDateString()
                            : "N/A"}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Total Properties</p>
                        <p className="font-semibold">{provider.total_properties}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="border-border text-center py-12">
              <p className="text-muted-foreground">No verified providers yet</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
