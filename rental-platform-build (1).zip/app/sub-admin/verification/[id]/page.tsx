import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import SubAdminVerificationReview from "@/components/sub-admin/sub-admin-verification-review"

export default async function SubAdminVerificationPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user || userData.user.user_metadata?.user_type !== "sub_admin") {
    redirect("/")
  }

  // Fetch provider details
  const { data: provider } = await supabase.from("providers").select("*").eq("id", id).single()

  if (!provider) {
    redirect("/sub-admin/dashboard")
  }

  // Fetch provider profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", id).single()

  return <SubAdminVerificationReview provider={provider} profile={profile} user={userData.user} />
}
