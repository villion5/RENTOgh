import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import SubAdminDashboard from "@/components/sub-admin/sub-admin-dashboard"

export default async function SubAdminDashboardPage() {
  const supabase = await createClient()

  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData?.user) {
    redirect("/auth/login")
  }

  // Verify user is sub-admin
  const userType = userData.user.user_metadata?.user_type
  if (userType !== "sub_admin") {
    redirect("/")
  }

  // Fetch dashboard data for verification purposes only
  const { data: providers } = await supabase.from("providers").select("id", { count: "exact" })

  const { data: verifiedProviders } = await supabase
    .from("providers")
    .select("id", { count: "exact" })
    .eq("is_verified", true)

  const { data: unverifiedProviders } = await supabase
    .from("providers")
    .select("id, business_name, created_at, is_verified, property_type")
    .eq("is_verified", false)
    .order("created_at", { ascending: false })

  return (
    <SubAdminDashboard
      user={userData.user}
      totalProviders={providers?.length || 0}
      verifiedProviders={verifiedProviders?.length || 0}
      unverifiedProviders={unverifiedProviders || []}
    />
  )
}
