import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function ProtectedPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  const user = data.user
  const userType = user.user_metadata?.user_type || "renter"
  const fullName = user.user_metadata?.full_name || user.email

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="bg-primary text-primary-foreground shadow-lg">
        <nav className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center font-bold text-primary">
              R
            </div>
            <span className="text-2xl font-bold">RENTOgh</span>
          </div>
          <div className="flex gap-4 items-center">
            <span className="text-sm">{fullName}</span>
            <form action="/api/auth/logout" method="POST">
              <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
                Logout
              </Button>
            </form>
          </div>
        </nav>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12">
        <div className="bg-card border border-border rounded-lg p-8">
          <h1 className="text-3xl font-bold mb-4">Welcome, {fullName}!</h1>
          <p className="text-muted-foreground mb-6">
            You are logged in as a <span className="font-semibold text-primary capitalize">{userType}</span>
          </p>

          <div className="space-y-4">
            <p className="text-sm">Your email: {user.email}</p>
            <p className="text-sm">Account created: {new Date(user.created_at).toLocaleDateString()}</p>
          </div>

          <div className="mt-8">
            <p className="text-muted-foreground mb-4">Next steps coming soon...</p>
            <Link href="/">
              <Button variant="outline">Back to Home</Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
