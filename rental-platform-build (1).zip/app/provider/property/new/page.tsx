import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import PropertyForm from "@/components/provider/property-form"

export default async function NewPropertyPage() {
  const supabase = await createClient()

  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData?.user) {
    redirect("/auth/login")
  }

  return <PropertyForm user={userData.user} />
}
