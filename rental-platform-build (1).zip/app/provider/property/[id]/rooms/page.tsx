import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import RoomManagement from "@/components/provider/room-management"

export default async function RoomManagementPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  // Fetch property
  const { data: property } = await supabase
    .from("properties")
    .select("*")
    .eq("id", id)
    .eq("provider_id", userData.user.id)
    .single()

  if (!property) {
    redirect("/provider/dashboard")
  }

  // Fetch rooms
  const { data: rooms } = await supabase.from("rooms").select("*").eq("property_id", id)

  return <RoomManagement property={property} rooms={rooms || []} user={userData.user} />
}
