import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import ProviderNav from "@/components/provider/provider-nav"
import SubscriptionManager from "@/components/provider/subscription-manager"

export default async function SubscriptionPage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  // Fetch provider
  const { data: provider } = await supabase.from("providers").select("*").eq("id", userData.user.id).single()

  // Fetch subscription plans
  const { data: plans } = await supabase.from("subscription_plans").select("*").order("annual_fee", { ascending: true })

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProviderNav user={userData.user} />

      <div className="max-w-4xl mx-auto px-6 py-12">
        <SubscriptionManager provider={provider} plans={plans || []} user={userData.user} />
      </div>
    </div>
  )
}
