import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import ProviderNav from "@/components/provider/provider-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

export default async function ProviderProfilePage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  // Fetch provider info
  const { data: provider } = await supabase.from("providers").select("*").eq("id", userData.user.id).single()

  // Fetch profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", userData.user.id).single()

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProviderNav user={userData.user} />

      <div className="max-w-2xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Provider Profile</h1>
          <p className="text-muted-foreground">Manage your provider account and business information</p>
        </div>

        {/* Business Information */}
        <Card className="border-border mb-6">
          <CardHeader>
            <CardTitle>Business Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Business Name</p>
                <p className="font-semibold">{provider?.business_name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Property Type</p>
                <p className="font-semibold capitalize">{provider?.property_type}</p>
              </div>
            </div>

            <div>
              <p className="text-sm text-muted-foreground mb-1">Contact Person</p>
              <p className="font-semibold">{provider?.contact_person_name}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Properties</p>
                <p className="font-semibold">{provider?.total_properties || 0}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Rooms</p>
                <p className="font-semibold">{provider?.total_rooms || 0}</p>
              </div>
            </div>

            <Link href="/provider/settings">
              <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 mt-4">
                Edit Business Information
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Verification Status */}
        <Card className="border-border mb-6">
          <CardHeader>
            <CardTitle>Verification Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Provider Verification</span>
              {provider?.is_verified ? (
                <Badge className="bg-accent text-accent-foreground">Verified</Badge>
              ) : (
                <Badge variant="destructive">Not Verified</Badge>
              )}
            </div>

            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Subscription Status</span>
              <Badge className={provider?.subscription_status === "active" ? "bg-accent text-accent-foreground" : ""}>
                {provider?.subscription_status}
              </Badge>
            </div>

            {provider?.subscription_expiry_date && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Expires</span>
                <span className="font-semibold">
                  {new Date(provider.subscription_expiry_date).toLocaleDateString()}
                </span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Rating */}
        {provider?.average_rating && (
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Provider Rating</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <span className="text-4xl font-bold text-accent">{provider.average_rating.toFixed(1)}</span>
                <div>
                  <p className="font-semibold">Out of 5 stars</p>
                  <p className="text-sm text-muted-foreground">Based on customer reviews</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
