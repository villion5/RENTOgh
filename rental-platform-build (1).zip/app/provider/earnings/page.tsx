import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import ProviderNav from "@/components/provider/provider-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"

export default async function EarningsPage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  // Fetch earnings
  const { data: earnings } = await supabase
    .from("provider_earnings")
    .select("*, bookings:public.bookings(*)")
    .eq("provider_id", userData.user.id)
    .order("created_at", { ascending: false })

  const totalEarnings = earnings?.reduce((sum, e) => sum + e.net_earnings, 0) || 0
  const pendingEarnings =
    earnings?.filter((e) => e.status === "pending").reduce((sum, e) => sum + e.net_earnings, 0) || 0
  const paidEarnings = earnings?.filter((e) => e.status === "paid").reduce((sum, e) => sum + e.net_earnings, 0) || 0
  const totalCommission = earnings?.reduce((sum, e) => sum + e.commission_amount, 0) || 0

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProviderNav user={userData.user} />

      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Earnings Report</h1>
          <p className="text-muted-foreground">View your detailed earnings and commission breakdown</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Total Earnings</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-accent">GHC {totalEarnings.toFixed(2)}</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Pending Payout</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">GHC {pendingEarnings.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground mt-1">Held in escrow</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Paid Out</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">GHC {paidEarnings.toFixed(2)}</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Commission Paid</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-destructive">GHC {totalCommission.toFixed(2)}</p>
            </CardContent>
          </Card>
        </div>

        {/* Detailed List */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle>Transaction Details</CardTitle>
            <CardDescription>Breakdown of all earnings and commissions</CardDescription>
          </CardHeader>
          <CardContent>
            {earnings && earnings.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b border-border">
                    <tr>
                      <th className="text-left py-3 px-4">Date</th>
                      <th className="text-left py-3 px-4">Booking</th>
                      <th className="text-right py-3 px-4">Base Amount</th>
                      <th className="text-right py-3 px-4">Commission (10-15%)</th>
                      <th className="text-right py-3 px-4">Your Earnings</th>
                      <th className="text-center py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {earnings.map((earning) => (
                      <tr key={earning.id} className="border-b border-border hover:bg-muted/50">
                        <td className="py-3 px-4">{format(new Date(earning.created_at), "MMM dd, yyyy")}</td>
                        <td className="py-3 px-4 font-medium">{earning.bookings?.id.slice(0, 8)}</td>
                        <td className="text-right py-3 px-4">GHC {earning.base_amount.toFixed(2)}</td>
                        <td className="text-right py-3 px-4 text-destructive">
                          -GHC {earning.commission_amount.toFixed(2)}
                        </td>
                        <td className="text-right py-3 px-4 font-bold text-accent">
                          GHC {earning.net_earnings.toFixed(2)}
                        </td>
                        <td className="text-center py-3 px-4">
                          <Badge className={earning.status === "paid" ? "bg-accent text-accent-foreground" : ""}>
                            {earning.status}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">No earnings yet</p>
            )}
          </CardContent>
        </Card>

        {/* Commission Info */}
        <Card className="border-border mt-8 bg-muted/30">
          <CardHeader>
            <CardTitle className="text-base">Commission Structure</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div className="border-r border-border pr-4">
                <p className="text-muted-foreground mb-1">Hotels</p>
                <p className="font-bold">15% commission</p>
              </div>
              <div className="border-r border-border pr-4">
                <p className="text-muted-foreground mb-1">Hostels</p>
                <p className="font-bold">10% commission</p>
              </div>
              <div>
                <p className="text-muted-foreground mb-1">Apartments</p>
                <p className="font-bold">10% commission</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              Commission is deducted from the total booking amount and sent to RENTOgh. Earnings are held in escrow
              until 24 hours after check-in verification, then released to your account.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
