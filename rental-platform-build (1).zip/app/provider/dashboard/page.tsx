import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import ProviderDashboard from "@/components/provider/provider-dashboard"

export default async function ProviderDashboardPage() {
  const supabase = await createClient()

  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData?.user) {
    redirect("/auth/login")
  }

  // Verify user is a provider
  const userType = userData.user.user_metadata?.user_type
  if (userType !== "provider") {
    redirect("/renter")
  }

  // Fetch provider info
  const { data: provider } = await supabase.from("providers").select("*").eq("id", userData.user.id).single()

  // Fetch provider's properties and bookings
  const { data: properties } = await supabase.from("properties").select("*").eq("provider_id", userData.user.id)

  const { data: bookings } = await supabase
    .from("bookings")
    .select("*, properties:public.properties(*), rooms:public.rooms(*)")
    .eq("provider_id", userData.user.id)
    .order("created_at", { ascending: false })
    .limit(10)

  const { data: earnings } = await supabase
    .from("provider_earnings")
    .select("*")
    .eq("provider_id", userData.user.id)
    .order("created_at", { ascending: false })

  return (
    <ProviderDashboard
      user={userData.user}
      provider={provider}
      properties={properties || []}
      bookings={bookings || []}
      earnings={earnings || []}
    />
  )
}
