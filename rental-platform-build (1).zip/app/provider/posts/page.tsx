import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import ProviderNav from "@/components/provider/provider-nav"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import ProviderPostsList from "@/components/provider/provider-posts-list"

export default async function ProviderPostsPage() {
  const supabase = await createClient()

  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData?.user) {
    redirect("/auth/login")
  }

  // Fetch provider's posts
  const { data: posts } = await supabase
    .from("provider_posts")
    .select("*, properties:public.properties(*)")
    .eq("provider_id", userData.user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProviderNav user={userData.user} />

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">My Posts</h1>
            <p className="text-muted-foreground">Share updates, offers, and announcements with renters</p>
          </div>
          <Link href="/provider/posts/new">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Create Post</Button>
          </Link>
        </div>

        <ProviderPostsList posts={posts || []} />
      </div>
    </div>
  )
}
