import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import PostForm from "@/components/provider/post-form"

export default async function NewPostPage() {
  const supabase = await createClient()

  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData?.user) {
    redirect("/auth/login")
  }

  // Fetch provider's properties
  const { data: properties } = await supabase.from("properties").select("id, name").eq("provider_id", userData.user.id)

  return <PostForm user={userData.user} properties={properties || []} />
}
