import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import ProviderNav from "@/components/provider/provider-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default async function ProviderBookingsPage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  // Fetch bookings for provider's properties
  const { data: bookings } = await supabase
    .from("bookings")
    .select(`
      *,
      room:room_id (id, property_id, name),
      renter:renter_id (id, full_name, email)
    `)
    .order("check_in_date", { ascending: false })

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProviderNav user={userData.user} />

      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Bookings</h1>
          <p className="text-muted-foreground">Manage all incoming bookings for your properties</p>
        </div>

        {bookings && bookings.length > 0 ? (
          <div className="space-y-4">
            {bookings.map((booking) => (
              <Card key={booking.id} className="border-border">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{booking.renter?.full_name || "Guest"}</CardTitle>
                      <CardDescription>Room: {booking.room?.name}</CardDescription>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        booking.status === "confirmed"
                          ? "bg-accent/20 text-accent-foreground"
                          : booking.status === "pending"
                            ? "bg-yellow-500/20 text-yellow-700"
                            : "bg-destructive/20 text-destructive"
                      }`}
                    >
                      {booking.status?.toUpperCase()}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Check-in</p>
                      <p className="font-semibold">{new Date(booking.check_in_date).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Check-out</p>
                      <p className="font-semibold">{new Date(booking.check_out_date).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Amount</p>
                      <p className="font-semibold">GHC {booking.total_amount}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Guest Email</p>
                      <p className="font-semibold text-sm">{booking.renter?.email}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      Contact Guest
                    </Button>
                    {booking.status === "pending" && (
                      <>
                        <Button size="sm" className="bg-accent text-accent-foreground">
                          Confirm
                        </Button>
                        <Button variant="destructive" size="sm">
                          Reject
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-border text-center py-12">
            <p className="text-muted-foreground mb-4">No bookings yet</p>
            <p className="text-sm text-muted-foreground">
              Your bookings will appear here when renters book your properties
            </p>
          </Card>
        )}
      </div>
    </div>
  )
}
