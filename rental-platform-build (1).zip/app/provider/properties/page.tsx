import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import ProviderNav from "@/components/provider/provider-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function ProviderPropertiesPage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  // Fetch provider's properties
  const { data: provider } = await supabase.from("providers").select("id").eq("user_id", userData.user.id).single()

  const { data: properties } = await supabase
    .from("properties")
    .select("*")
    .eq("provider_id", provider?.id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProviderNav user={userData.user} />

      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">My Properties</h1>
            <p className="text-muted-foreground">Manage your rental properties</p>
          </div>
          <Link href="/provider/property/new">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Add Property</Button>
          </Link>
        </div>

        {properties && properties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {properties.map((property) => (
              <Card key={property.id} className="border-border hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="line-clamp-2">{property.name}</CardTitle>
                  <CardDescription>
                    {property.city}, {property.region}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-muted-foreground">Type</p>
                      <p className="font-semibold capitalize">{property.property_type}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Status</p>
                      <p className="font-semibold capitalize">{property.availability_status}</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">{property.description}</p>
                  <Link href={`/provider/property/${property.id}/rooms`}>
                    <Button variant="outline" className="w-full bg-transparent">
                      Manage Rooms
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-border text-center py-12">
            <p className="text-muted-foreground mb-4">No properties yet</p>
            <Link href="/provider/property/new">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                Add Your First Property
              </Button>
            </Link>
          </Card>
        )}
      </div>
    </div>
  )
}
