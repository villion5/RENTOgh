import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import AdminNav from "@/components/admin/admin-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { format } from "date-fns"

export default async function RevenueReportPage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user || userData.user.user_metadata?.user_type !== "admin") {
    redirect("/")
  }

  // Fetch all bookings
  const { data: bookings } = await supabase
    .from("bookings")
    .select("*, properties:public.properties(*)")
    .order("created_at", { ascending: false })

  // Calculate revenue metrics
  const totalBookingValue = bookings?.reduce((sum, b) => sum + b.total_price, 0) || 0
  const hotelBookings = bookings?.filter((b) => b.properties?.property_type === "hotel") || []
  const hostelBookings = bookings?.filter((b) => b.properties?.property_type === "hostel") || []
  const apartmentBookings = bookings?.filter((b) => b.properties?.property_type === "apartment") || []

  const hotelCommission = hotelBookings.reduce((sum, b) => sum + b.total_price * 0.15, 0)
  const hostelCommission = hostelBookings.reduce((sum, b) => sum + b.total_price * 0.1, 0)
  const apartmentCommission = apartmentBookings.reduce((sum, b) => sum + b.total_price * 0.1, 0)
  const totalCommission = hotelCommission + hostelCommission + apartmentCommission

  return (
    <div className="min-h-screen bg-background text-foreground">
      <AdminNav user={userData.user} />

      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Revenue Report</h1>
          <p className="text-muted-foreground">Platform revenue and commission analysis</p>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Total Booking Value</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">GHC {totalBookingValue.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground mt-1">{bookings?.length || 0} bookings</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Total Commission</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-accent">GHC {totalCommission.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {((totalCommission / totalBookingValue) * 100).toFixed(1)}% of booking value
              </p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Average Booking</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">GHC {(totalBookingValue / (bookings?.length || 1)).toFixed(2)}</p>
            </CardContent>
          </Card>
        </div>

        {/* Commission by Type */}
        <Card className="border-border mb-8">
          <CardHeader>
            <CardTitle>Commission by Property Type</CardTitle>
            <CardDescription>Revenue breakdown by property type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold">Hotels (15% commission)</span>
                  <span className="text-sm text-muted-foreground">{hotelBookings.length} bookings</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Commission earned:</span>
                  <span className="font-bold text-lg">GHC {hotelCommission.toFixed(2)}</span>
                </div>
              </div>

              <div className="border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold">Hostels (10% commission)</span>
                  <span className="text-sm text-muted-foreground">{hostelBookings.length} bookings</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Commission earned:</span>
                  <span className="font-bold text-lg">GHC {hostelCommission.toFixed(2)}</span>
                </div>
              </div>

              <div className="border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold">Apartments (10% commission)</span>
                  <span className="text-sm text-muted-foreground">{apartmentBookings.length} bookings</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Commission earned:</span>
                  <span className="font-bold text-lg">GHC {apartmentCommission.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Transactions */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            {bookings && bookings.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b border-border">
                    <tr>
                      <th className="text-left py-3 px-4">Date</th>
                      <th className="text-left py-3 px-4">Property</th>
                      <th className="text-left py-3 px-4">Type</th>
                      <th className="text-right py-3 px-4">Amount</th>
                      <th className="text-right py-3 px-4">Commission</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bookings.slice(0, 20).map((booking) => {
                      const commissionRate = booking.properties?.property_type === "hotel" ? 0.15 : 0.1
                      const commission = booking.total_price * commissionRate
                      return (
                        <tr key={booking.id} className="border-b border-border hover:bg-muted/50">
                          <td className="py-3 px-4">{format(new Date(booking.created_at), "MMM dd, yyyy")}</td>
                          <td className="py-3 px-4 font-medium">{booking.properties?.name}</td>
                          <td className="py-3 px-4 capitalize">{booking.properties?.property_type}</td>
                          <td className="text-right py-3 px-4">GHC {booking.total_price.toFixed(2)}</td>
                          <td className="text-right py-3 px-4 font-bold text-accent">GHC {commission.toFixed(2)}</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">No transactions yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
