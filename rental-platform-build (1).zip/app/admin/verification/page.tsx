import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import AdminNav from "@/components/admin/admin-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function AdminVerificationPage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  // Fetch pending provider verifications
  const { data: pendingProviders } = await supabase
    .from("providers")
    .select("*")
    .eq("verification_status", "pending")
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background text-foreground">
      <AdminNav user={userData.user} />

      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Provider Verification</h1>
          <p className="text-muted-foreground">Review and approve pending provider applications</p>
        </div>

        {pendingProviders && pendingProviders.length > 0 ? (
          <div className="space-y-4">
            {pendingProviders.map((provider) => (
              <Card key={provider.id} className="border-border">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{provider.company_name}</CardTitle>
                      <CardDescription>{provider.business_email}</CardDescription>
                    </div>
                    <span className="px-3 py-1 rounded-full text-sm font-medium bg-yellow-500/20 text-yellow-700">
                      PENDING
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Owner Name</p>
                      <p className="font-semibold">{provider.owner_name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Phone</p>
                      <p className="font-semibold">{provider.phone_number}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Location</p>
                      <p className="font-semibold">{provider.location}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Applied</p>
                      <p className="font-semibold">{new Date(provider.created_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Link href={`/admin/verification/${provider.id}`}>
                      <Button variant="outline" size="sm">
                        Review Details
                      </Button>
                    </Link>
                    <Button size="sm" className="bg-accent text-accent-foreground">
                      Approve
                    </Button>
                    <Button variant="destructive" size="sm">
                      Reject
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-border text-center py-12">
            <p className="text-muted-foreground mb-4">No pending verifications</p>
            <p className="text-sm text-muted-foreground">All providers have been verified</p>
          </Card>
        )}
      </div>
    </div>
  )
}
