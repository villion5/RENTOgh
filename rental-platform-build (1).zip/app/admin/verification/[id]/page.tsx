import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import VerificationReview from "@/components/admin/verification-review"

export default async function VerificationPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user || userData.user.user_metadata?.user_type !== "admin") {
    redirect("/")
  }

  // Fetch provider details
  const { data: provider } = await supabase.from("providers").select("*").eq("id", id).single()

  if (!provider) {
    redirect("/admin/dashboard")
  }

  // Fetch provider profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", id).single()

  return <VerificationReview provider={provider} profile={profile} user={userData.user} />
}
