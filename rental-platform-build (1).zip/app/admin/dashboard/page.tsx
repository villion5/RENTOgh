import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import AdminDashboard from "@/components/admin/admin-dashboard"

export default async function AdminDashboardPage() {
  const supabase = await createClient()

  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData?.user) {
    redirect("/auth/login")
  }

  // Verify user is admin
  const userType = userData.user.user_metadata?.user_type
  if (userType !== "admin") {
    redirect("/")
  }

  // Fetch dashboard data
  const { data: totalUsers } = await supabase.from("profiles").select("id", { count: "exact" })

  const { data: providers } = await supabase.from("providers").select("id", { count: "exact" })

  const { data: verifiedProviders } = await supabase
    .from("providers")
    .select("id", { count: "exact" })
    .eq("is_verified", true)

  const { data: bookings } = await supabase
    .from("bookings")
    .select("total_price, booking_status")
    .order("created_at", { ascending: false })
    .limit(100)

  const { data: unverifiedProviders } = await supabase
    .from("providers")
    .select("id, business_name, created_at, is_verified")
    .eq("is_verified", false)
    .order("created_at", { ascending: false })
    .limit(10)

  return (
    <AdminDashboard
      user={userData.user}
      totalUsers={totalUsers?.length || 0}
      totalProviders={providers?.length || 0}
      verifiedProviders={verifiedProviders?.length || 0}
      totalBookings={bookings?.length || 0}
      totalRevenue={bookings?.reduce((sum: number, b: any) => sum + b.total_price * 0.15, 0) || 0}
      unverifiedProviders={unverifiedProviders || []}
    />
  )
}
