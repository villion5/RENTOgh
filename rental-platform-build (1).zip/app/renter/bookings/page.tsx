import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import RenterNav from "@/components/renter/renter-nav"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default async function BookingsPage() {
  const supabase = await createClient()

  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData?.user) {
    redirect("/auth/login")
  }

  // Fetch user's bookings
  const { data: bookings, error } = await supabase
    .from("bookings")
    .select("*, properties:public.properties(*), rooms:public.rooms(*)")
    .eq("renter_id", userData.user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background text-foreground">
      <RenterNav user={userData.user} />

      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My Bookings</h1>
          <p className="text-muted-foreground">View and manage all your property bookings</p>
        </div>

        {bookings && bookings.length > 0 ? (
          <div className="space-y-4">
            {bookings.map((booking: any) => (
              <Card key={booking.id} className="border-border hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{booking.properties?.name}</CardTitle>
                      <CardDescription>{booking.properties?.location}</CardDescription>
                    </div>
                    <Badge className={booking.booking_status === "confirmed" ? "bg-accent text-accent-foreground" : ""}>
                      {booking.booking_status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Check-in</p>
                      <p className="font-semibold">{new Date(booking.check_in_date).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Check-out</p>
                      <p className="font-semibold">{new Date(booking.check_out_date).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Nights</p>
                      <p className="font-semibold">{booking.number_of_nights}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total</p>
                      <p className="font-semibold text-accent">GHC {booking.total_price.toFixed(2)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-border">
            <CardContent className="pt-12 pb-12 text-center">
              <p className="text-lg text-muted-foreground mb-4">You haven't made any bookings yet</p>
              <Link href="/renter">
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Browse Properties</Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
