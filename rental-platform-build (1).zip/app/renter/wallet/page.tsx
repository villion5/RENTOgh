import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import RenterNav from "@/components/renter/renter-nav"
import WalletClient from "@/components/renter/wallet-client"

export default async function WalletPage() {
  const supabase = await createClient()

  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData?.user) {
    redirect("/auth/login")
  }

  // Fetch or create wallet
  let { data: wallet } = await supabase.from("wallets").select("*").eq("user_id", userData.user.id).single()

  if (!wallet) {
    // Create wallet if doesn't exist
    const { data: newWallet } = await supabase
      .from("wallets")
      .insert({
        user_id: userData.user.id,
        balance: 0,
        total_funded: 0,
        total_spent: 0,
      })
      .select()
      .single()
    wallet = newWallet
  }

  // Fetch wallet transactions
  const { data: transactions } = await supabase
    .from("wallet_transactions")
    .select("*")
    .eq("wallet_id", wallet?.id)
    .order("created_at", { ascending: false })
    .limit(10)

  return (
    <div className="min-h-screen bg-background text-foreground">
      <RenterNav user={userData.user} />

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My Wallet</h1>
          <p className="text-muted-foreground">Manage your balance and funding</p>
        </div>

        <WalletClient wallet={wallet} transactions={transactions || []} userId={userData.user.id} />
      </div>
    </div>
  )
}
