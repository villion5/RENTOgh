import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import RenterNav from "@/components/renter/renter-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default async function RenterReviewsPage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  const { data: reviews } = await supabase
    .from("reviews")
    .select("*")
    .eq("renter_id", userData.user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background text-foreground">
      <RenterNav user={userData.user} />

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My Reviews</h1>
          <p className="text-muted-foreground">Reviews and ratings you've received from properties</p>
        </div>

        {reviews && reviews.length > 0 ? (
          <div className="space-y-4">
            {reviews.map((review) => (
              <Card key={review.id} className="border-border">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">Property ID: {review.property_id}</CardTitle>
                      <CardDescription>{new Date(review.created_at).toLocaleDateString()}</CardDescription>
                    </div>
                    <div className="text-2xl">
                      {"⭐".repeat(review.rating)}
                      {"☆".repeat(5 - review.rating)}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground">{review.comment || "No comment provided"}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-border text-center py-12">
            <p className="text-muted-foreground mb-4">No reviews yet</p>
            <p className="text-sm text-muted-foreground">
              Your reviews from properties will appear here after your first booking
            </p>
          </Card>
        )}
      </div>
    </div>
  )
}
