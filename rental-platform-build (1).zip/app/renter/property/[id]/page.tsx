import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import PropertyDetails from "@/components/renter/property-details"

export default async function PropertyPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()

  // Verify user is authenticated
  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData?.user) {
    redirect("/auth/login")
  }

  // Fetch property details
  const { data: property, error } = await supabase
    .from("properties")
    .select("*, rooms:public.rooms(*)")
    .eq("id", id)
    .eq("is_verified", true)
    .single()

  if (error || !property) {
    redirect("/renter")
  }

  return <PropertyDetails property={property} userId={userData.user.id} />
}
