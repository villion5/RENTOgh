import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import RenterNav from "@/components/renter/renter-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default async function RenterProfilePage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  // Fetch user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", userData.user.id).single()

  // Fetch user's review count
  const { data: reviews, count: reviewCount } = await supabase
    .from("reviews")
    .select("*", { count: "exact" })
    .eq("renter_id", userData.user.id)

  return (
    <div className="min-h-screen bg-background text-foreground">
      <RenterNav user={userData.user} />

      <div className="max-w-2xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My Profile</h1>
          <p className="text-muted-foreground">View and manage your account information</p>
        </div>

        {/* Profile Card */}
        <Card className="border-border mb-6">
          <CardHeader>
            <CardTitle>Account Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Full Name</p>
                <p className="font-semibold">{profile?.full_name || userData.user.user_metadata?.full_name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Email</p>
                <p className="font-semibold">{userData.user.email}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Phone Number</p>
                <p className="font-semibold">{profile?.phone_number || "Not provided"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Gender</p>
                <p className="font-semibold capitalize">{profile?.gender || "Not provided"}</p>
              </div>
            </div>

            <div>
              <p className="text-sm text-muted-foreground mb-1">Address</p>
              <p className="font-semibold">{profile?.address || "Not provided"}</p>
            </div>

            <Link href="/renter/profile/edit">
              <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 mt-4">
                Edit Profile
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Verification Status */}
        <Card className="border-border mb-6">
          <CardHeader>
            <CardTitle>Verification Status</CardTitle>
          </CardHeader>
          <CardContent>
            {profile?.is_verified ? (
              <div className="flex items-center gap-2">
                <span className="text-2xl">✓</span>
                <div>
                  <p className="font-semibold">Email Verified</p>
                  <p className="text-sm text-muted-foreground">
                    Verified on{" "}
                    {profile.verification_date ? new Date(profile.verification_date).toLocaleDateString() : ""}
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center">
                <p className="text-muted-foreground mb-4">
                  Complete your email verification to unlock higher wallet limits
                </p>
                <Button variant="outline">Verify Email</Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Reviews */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle>My Reviews</CardTitle>
            <CardDescription>
              {reviewCount || 0} review{reviewCount !== 1 ? "s" : ""}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/renter/reviews">
              <Button variant="outline" className="w-full bg-transparent">
                View All Reviews
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
