import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import RenterHomepage from "@/components/renter/renter-homepage"

export default async function RenterPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Verify user is a renter
  const userType = data.user.user_metadata?.user_type
  if (userType !== "renter") {
    redirect("/provider/dashboard")
  }

  return <RenterHomepage user={data.user} />
}
