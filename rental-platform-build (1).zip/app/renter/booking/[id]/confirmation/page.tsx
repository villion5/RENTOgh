import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import RenterNav from "@/components/renter/renter-nav"
import { CheckCircle2 } from "lucide-react"
import { format } from "date-fns"

export default async function BookingConfirmationPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  const { data: booking } = await supabase
    .from("bookings")
    .select("*, properties:public.properties(*), rooms:public.rooms(*)")
    .eq("id", id)
    .eq("renter_id", userData.user.id)
    .single()

  if (!booking) {
    redirect("/renter/bookings")
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <RenterNav user={userData.user} />

      <div className="max-w-2xl mx-auto px-6 py-12">
        {/* Success Message */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <CheckCircle2 className="w-16 h-16 text-accent" />
          </div>
          <h1 className="text-3xl font-bold mb-2">Booking Confirmed!</h1>
          <p className="text-muted-foreground">Your reservation has been successfully created</p>
        </div>

        {/* Booking Details */}
        <Card className="border-border mb-8">
          <CardHeader>
            <CardTitle>Booking Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Booking ID</p>
                <p className="font-mono text-sm font-semibold">{booking.id.slice(0, 8)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Status</p>
                <Badge className="bg-accent text-accent-foreground capitalize">{booking.booking_status}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Property Information */}
        <Card className="border-border mb-8">
          <CardHeader>
            <CardTitle>{booking.properties?.name}</CardTitle>
            <CardDescription>{booking.properties?.location}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Room Type:</span>
              <span className="font-semibold capitalize">{booking.rooms?.room_type}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Check-in:</span>
              <span className="font-semibold">{format(new Date(booking.check_in_date), "MMMM dd, yyyy")}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Check-out:</span>
              <span className="font-semibold">{format(new Date(booking.check_out_date), "MMMM dd, yyyy")}</span>
            </div>
          </CardContent>
        </Card>

        {/* Payment Summary */}
        <Card className="border-accent bg-accent/5 mb-8">
          <CardHeader>
            <CardTitle>Payment Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">{booking.number_of_nights} nights</span>
              <span>GHC {booking.base_price.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Commission</span>
              <span>GHC {booking.commission_amount.toFixed(2)}</span>
            </div>
            <div className="border-t border-accent/20 pt-2 flex justify-between font-bold">
              <span>Total Paid:</span>
              <span className="text-lg text-accent">GHC {booking.total_price.toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>

        {/* Important Notes */}
        <Card className="border-border bg-muted/30 mb-8">
          <CardContent className="pt-6">
            <p className="text-sm font-semibold mb-2">Important Information:</p>
            <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
              <li>A confirmation email has been sent to your email address</li>
              <li>Your payment is held in escrow and will be released after check-in</li>
              <li>Contact the property manager 24 hours before arrival</li>
              <li>Bring a valid ID for check-in</li>
            </ul>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-4 justify-center">
          <Link href="/renter/bookings">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">View All Bookings</Button>
          </Link>
          <Link href="/renter">
            <Button variant="outline">Continue Browsing</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
