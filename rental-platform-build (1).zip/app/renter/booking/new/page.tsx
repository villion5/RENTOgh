import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import BookingFlow from "@/components/renter/booking-flow"

export default async function NewBookingPage({
  searchParams,
}: {
  searchParams: Promise<{ room?: string; property?: string }>
}) {
  const params = await searchParams
  const { room: roomId, property: propertyId } = params

  if (!roomId || !propertyId) {
    redirect("/renter")
  }

  const supabase = await createClient()

  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData?.user) {
    redirect("/auth/login")
  }

  // Fetch room and property details
  const { data: room } = await supabase.from("rooms").select("*").eq("id", roomId).single()

  const { data: property } = await supabase.from("properties").select("*").eq("id", propertyId).single()

  if (!room || !property) {
    redirect("/renter")
  }

  // Fetch wallet
  let { data: wallet } = await supabase.from("wallets").select("*").eq("user_id", userData.user.id).single()

  if (!wallet) {
    const { data: newWallet } = await supabase
      .from("wallets")
      .insert({
        user_id: userData.user.id,
        balance: 0,
      })
      .select()
      .single()
    wallet = newWallet
  }

  return <BookingFlow room={room} property={property} wallet={wallet} userId={userData.user.id} />
}
