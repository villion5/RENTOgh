import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import RenterNav from "@/components/renter/renter-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default async function RenterSettingsPage() {
  const supabase = await createClient()

  const { data: userData } = await supabase.auth.getUser()
  if (!userData?.user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", userData.user.id).single()

  return (
    <div className="min-h-screen bg-background text-foreground">
      <RenterNav user={userData.user} />

      <div className="max-w-2xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Settings</h1>
          <p className="text-muted-foreground">Manage your account preferences and security</p>
        </div>

        {/* Notification Settings */}
        <Card className="border-border mb-6">
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
            <CardDescription>Control how and when you receive updates</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between py-3 border-b border-border">
              <div>
                <p className="font-semibold">Email Notifications</p>
                <p className="text-sm text-muted-foreground">Receive updates about bookings and messages</p>
              </div>
              <input type="checkbox" defaultChecked className="w-5 h-5" />
            </div>
            <div className="flex items-center justify-between py-3 border-b border-border">
              <div>
                <p className="font-semibold">SMS Notifications</p>
                <p className="text-sm text-muted-foreground">Get alerts on your phone</p>
              </div>
              <input type="checkbox" defaultChecked className="w-5 h-5" />
            </div>
            <div className="flex items-center justify-between py-3">
              <div>
                <p className="font-semibold">Marketing Emails</p>
                <p className="text-sm text-muted-foreground">Promotions and new features</p>
              </div>
              <input type="checkbox" className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>

        {/* Privacy Settings */}
        <Card className="border-border mb-6">
          <CardHeader>
            <CardTitle>Privacy & Security</CardTitle>
            <CardDescription>Keep your account safe and private</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Link href="/renter/settings/change-password">
              <Button variant="outline" className="w-full justify-start bg-transparent">
                Change Password
              </Button>
            </Link>
            <Link href="/renter/settings/security">
              <Button variant="outline" className="w-full justify-start bg-transparent">
                Two-Factor Authentication
              </Button>
            </Link>
            <Button
              variant="outline"
              className="w-full justify-start text-destructive hover:text-destructive bg-transparent"
            >
              Delete Account
            </Button>
          </CardContent>
        </Card>

        {/* Account Info */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle>Account Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Account Created</span>
              <span>{new Date(userData.user.created_at).toLocaleDateString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Email</span>
              <span>{userData.user.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Verification Status</span>
              <span className={profile?.is_verified ? "text-accent" : "text-destructive"}>
                {profile?.is_verified ? "Verified" : "Not Verified"}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
