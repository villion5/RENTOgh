-- Subscription plans table
CREATE TABLE IF NOT EXISTS public.subscription_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(100) NOT NULL,
  annual_fee DECIMAL(10, 2) NOT NULL,
  benefits TEXT[],
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default plans
INSERT INTO public.subscription_plans (name, annual_fee, benefits) VALUES
  ('Basic', 50.00, ARRAY['List properties', 'Basic analytics', 'Email support']),
  ('Professional', 100.00, ARRAY['List properties', 'Advanced analytics', 'Priority support', 'Marketing tools']),
  ('Premium', 200.00, ARRAY['List properties', 'Advanced analytics', '24/7 priority support', 'Marketing tools', 'Dedicated account manager'])
ON CONFLICT DO NOTHING;

-- Subscription transactions table
CREATE TABLE IF NOT EXISTS public.subscription_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  provider_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_id UUID NOT NULL REFERENCES public.subscription_plans(id),
  amount DECIMAL(10, 2) NOT NULL,
  transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  renewal_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Enable RLS
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscription_transactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can view subscription plans"
  ON public.subscription_plans FOR SELECT
  USING (true);

CREATE POLICY "Providers can view their transactions"
  ON public.subscription_transactions FOR SELECT
  USING (auth.uid() = provider_id);
