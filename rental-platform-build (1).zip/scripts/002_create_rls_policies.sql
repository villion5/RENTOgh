-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Anyone can view public provider profiles"
  ON public.profiles FOR SELECT
  USING (user_type = 'provider');

-- RLS Policies for providers
CREATE POLICY "Providers can view their own data"
  ON public.providers FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Providers can update their own data"
  ON public.providers FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Anyone can view verified providers"
  ON public.providers FOR SELECT
  USING (is_verified = true);

-- Sub-admin access policies for providers
CREATE POLICY "Sub-admins can view provider verification data"
  ON public.providers FOR SELECT
  USING (
    auth.jwt() ->> 'user_metadata' ->> 'user_type' = 'sub_admin'
  );

CREATE POLICY "Sub-admins can update provider verification status"
  ON public.providers FOR UPDATE
  USING (
    auth.jwt() ->> 'user_metadata' ->> 'user_type' = 'sub_admin'
  )
  WITH CHECK (
    auth.jwt() ->> 'user_metadata' ->> 'user_type' = 'sub_admin'
  );

-- RLS Policies for properties
CREATE POLICY "Providers can view their own properties"
  ON public.properties FOR SELECT
  USING (auth.uid() = provider_id);

CREATE POLICY "Providers can insert properties"
  ON public.properties FOR INSERT
  WITH CHECK (auth.uid() = provider_id);

CREATE POLICY "Providers can update their own properties"
  ON public.properties FOR UPDATE
  USING (auth.uid() = provider_id);

CREATE POLICY "Anyone can view verified properties"
  ON public.properties FOR SELECT
  USING (is_verified = true);

-- RLS Policies for rooms
CREATE POLICY "Providers can view their own rooms"
  ON public.rooms FOR SELECT
  USING (auth.uid() = provider_id);

CREATE POLICY "Providers can manage their own rooms"
  ON public.rooms FOR INSERT
  WITH CHECK (auth.uid() = provider_id);

CREATE POLICY "Providers can update their own rooms"
  ON public.rooms FOR UPDATE
  USING (auth.uid() = provider_id);

CREATE POLICY "Anyone can view available rooms"
  ON public.rooms FOR SELECT
  USING (is_available = true);

-- RLS Policies for bookings
CREATE POLICY "Renters can view their own bookings"
  ON public.bookings FOR SELECT
  USING (auth.uid() = renter_id);

CREATE POLICY "Providers can view their bookings"
  ON public.bookings FOR SELECT
  USING (auth.uid() = provider_id);

CREATE POLICY "Renters can create bookings"
  ON public.bookings FOR INSERT
  WITH CHECK (auth.uid() = renter_id);

-- RLS Policies for wallets
CREATE POLICY "Users can view their own wallet"
  ON public.wallets FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own wallet"
  ON public.wallets FOR UPDATE
  USING (auth.uid() = user_id);

-- RLS Policies for wallet transactions
CREATE POLICY "Users can view their own transactions"
  ON public.wallet_transactions FOR SELECT
  USING (auth.uid() = (SELECT user_id FROM public.wallets WHERE id = wallet_id));

-- RLS Policies for provider earnings
CREATE POLICY "Providers can view their earnings"
  ON public.provider_earnings FOR SELECT
  USING (auth.uid() = provider_id);

-- RLS Policies for provider posts
CREATE POLICY "Providers can view their own posts"
  ON public.provider_posts FOR SELECT
  USING (auth.uid() = provider_id);

CREATE POLICY "Anyone can view published provider posts"
  ON public.provider_posts FOR SELECT
  USING (is_published = true);

CREATE POLICY "Providers can create posts"
  ON public.provider_posts FOR INSERT
  WITH CHECK (auth.uid() = provider_id);

CREATE POLICY "Providers can update their own posts"
  ON public.provider_posts FOR UPDATE
  USING (auth.uid() = provider_id);

-- RLS Policies for reviews
CREATE POLICY "Users can view all reviews"
  ON public.reviews FOR SELECT
  USING (true);

CREATE POLICY "Renters can create reviews"
  ON public.reviews FOR INSERT
  WITH CHECK (auth.uid() = renter_id);
