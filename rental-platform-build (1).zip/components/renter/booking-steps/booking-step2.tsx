"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { Separator } from "@/components/ui/separator"

interface Room {
  room_type: string
  price_per_night: number
}

interface Property {
  name: string
  property_type: string
  location: string
}

export default function BookingStep2({
  checkInDate,
  checkOutDate,
  numberOfNights,
  basePrice,
  commissionAmount,
  totalPrice,
  room,
  property,
}: {
  checkInDate: Date | null
  checkOutDate: Date | null
  numberOfNights: number
  basePrice: number
  commissionAmount: number
  totalPrice: number
  room: Room
  property: Property
}) {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold">Review Your Booking</h3>

      {/* Property Details */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-base">{property.name}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Location:</span>
            <span className="font-medium">{property.location}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Property Type:</span>
            <Badge variant="outline" className="capitalize">
              {property.property_type}
            </Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Room Type:</span>
            <span className="font-medium capitalize">{room.room_type}</span>
          </div>
        </CardContent>
      </Card>

      {/* Booking Dates */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-base">Booking Dates</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Check-in:</span>
            <span className="font-medium">{checkInDate && format(checkInDate, "MMMM dd, yyyy")}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Check-out:</span>
            <span className="font-medium">{checkOutDate && format(checkOutDate, "MMMM dd, yyyy")}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Total Nights:</span>
            <Badge className="bg-primary text-primary-foreground">{numberOfNights}</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Price Breakdown */}
      <Card className="border-accent bg-accent/5">
        <CardHeader>
          <CardTitle className="text-base">Price Breakdown</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between">
            <span className="text-muted-foreground">
              {numberOfNights} night{numberOfNights > 1 ? "s" : ""} × GHC {room.price_per_night.toFixed(2)}
            </span>
            <span className="font-medium">GHC {basePrice.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">
              Platform Commission ({property.property_type === "hotel" ? "15%" : "10%"}):
            </span>
            <span className="font-medium">GHC {commissionAmount.toFixed(2)}</span>
          </div>
          <Separator className="my-2" />
          <div className="flex justify-between items-center">
            <span className="font-semibold">Total Amount:</span>
            <span className="text-2xl font-bold text-accent">GHC {totalPrice.toFixed(2)}</span>
          </div>
        </CardContent>
      </Card>

      {/* Info Box */}
      <Card className="border-border bg-muted/30">
        <CardContent className="pt-6">
          <p className="text-sm text-muted-foreground">
            The total amount will be deducted from your wallet upon confirmation. Funds are held in escrow and released
            to the provider after check-in verification.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
