"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { Badge } from "@/components/ui/badge"

interface Room {
  room_type: string
  price_per_night: number
  capacity: number
}

interface Property {
  name: string
  location: string
}

export default function BookingStep1({
  checkInDate,
  checkOutDate,
  onCheckInChange,
  onCheckOutChange,
  room,
  property,
}: {
  checkInDate: Date | null
  checkOutDate: Date | null
  onCheckInChange: (date: Date | null) => void
  onCheckOutChange: (date: Date | null) => void
  room: Room
  property: Property
}) {
  const [isCheckInOpen, setIsCheckInOpen] = useState(false)
  const [isCheckOutOpen, setIsCheckOutOpen] = useState(false)

  const numberOfNights =
    checkInDate && checkOutDate
      ? Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24))
      : 0

  const totalPrice = numberOfNights * room.price_per_night

  return (
    <div className="space-y-6">
      {/* Property and Room Summary */}
      <Card className="border-border bg-muted/30">
        <CardHeader>
          <CardTitle>{property.name}</CardTitle>
          <CardDescription>{property.location}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Room Type</p>
              <p className="font-semibold capitalize">{room.room_type}</p>
              <p className="text-sm text-muted-foreground mt-2">
                Capacity: {room.capacity} person{room.capacity > 1 ? "s" : ""}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground mb-1">Price per Night</p>
              <p className="text-2xl font-bold text-accent">GHC {room.price_per_night.toFixed(2)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Date Selection */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Select Your Dates</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Check-in Date */}
          <div>
            <label className="text-sm font-medium mb-2 block">Check-in Date</label>
            <Popover open={isCheckInOpen} onOpenChange={setIsCheckInOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal bg-transparent">
                  {checkInDate ? format(checkInDate, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={checkInDate || undefined}
                  onSelect={(date) => {
                    onCheckInChange(date || null)
                    setIsCheckInOpen(false)
                  }}
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Check-out Date */}
          <div>
            <label className="text-sm font-medium mb-2 block">Check-out Date</label>
            <Popover open={isCheckOutOpen} onOpenChange={setIsCheckOutOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal bg-transparent">
                  {checkOutDate ? format(checkOutDate, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={checkOutDate || undefined}
                  onSelect={(date) => {
                    onCheckOutChange(date || null)
                    setIsCheckOutOpen(false)
                  }}
                  disabled={(date) => date <= (checkInDate || new Date()) || date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </div>

      {/* Booking Summary */}
      {numberOfNights > 0 && (
        <Card className="border-accent bg-accent/5">
          <CardHeader>
            <CardTitle className="text-lg">Booking Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Check-in:</span>
              <span className="font-semibold">{checkInDate && format(checkInDate, "MMM dd, yyyy")}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Check-out:</span>
              <span className="font-semibold">{checkOutDate && format(checkOutDate, "MMM dd, yyyy")}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Number of Nights:</span>
              <Badge className="bg-primary text-primary-foreground">
                {numberOfNights} night{numberOfNights > 1 ? "s" : ""}
              </Badge>
            </div>
            <div className="border-t border-accent/20 pt-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Subtotal:</span>
                <span className="font-semibold">GHC {totalPrice.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
