"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, CheckCircle2 } from "lucide-react"
import { format } from "date-fns"
import { Separator } from "@/components/ui/separator"

interface Wallet {
  balance: number
}

interface Room {
  room_type: string
  price_per_night: number
}

interface Property {
  name: string
  location: string
}

export default function BookingStep3({
  wallet,
  totalPrice,
  checkInDate,
  checkOutDate,
  numberOfNights,
  room,
  property,
}: {
  wallet: Wallet
  totalPrice: number
  checkInDate: Date | null
  checkOutDate: Date | null
  numberOfNights: number
  room: Room
  property: Property
}) {
  const remainingBalance = wallet.balance - totalPrice
  const hasSufficientFunds = wallet.balance >= totalPrice

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold">Confirm Payment</h3>

      {/* Fund Status */}
      <Card className={hasSufficientFunds ? "border-accent bg-accent/5" : "border-destructive bg-destructive/5"}>
        <CardContent className="pt-6 flex items-start gap-4">
          {hasSufficientFunds ? (
            <>
              <CheckCircle2 className="w-6 h-6 text-accent flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-accent mb-1">Sufficient Funds</p>
                <p className="text-sm text-muted-foreground">You have enough balance to complete this booking.</p>
              </div>
            </>
          ) : (
            <>
              <AlertCircle className="w-6 h-6 text-destructive flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-destructive mb-1">Insufficient Funds</p>
                <p className="text-sm text-muted-foreground">
                  You need GHC {(totalPrice - wallet.balance).toFixed(2)} more to complete this booking.
                </p>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Wallet Balance */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-base">Payment Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Current Balance:</span>
            <span className="font-semibold">GHC {wallet.balance.toFixed(2)}</span>
          </div>

          <Separator />

          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Booking Amount:</span>
            <span className="font-semibold text-destructive">-GHC {totalPrice.toFixed(2)}</span>
          </div>

          <Separator />

          <div className="flex justify-between items-center bg-muted/50 p-3 rounded-lg">
            <span className="font-semibold">Remaining Balance:</span>
            <span className={`text-lg font-bold ${remainingBalance < 0 ? "text-destructive" : "text-accent"}`}>
              GHC {Math.max(0, remainingBalance).toFixed(2)}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Booking Summary */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-base">Booking Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Property:</span>
            <span className="font-medium">{property.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Room:</span>
            <span className="font-medium capitalize">{room.room_type}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Check-in:</span>
            <span className="font-medium">{checkInDate && format(checkInDate, "MMM dd, yyyy")}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Check-out:</span>
            <span className="font-medium">{checkOutDate && format(checkOutDate, "MMM dd, yyyy")}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Duration:</span>
            <Badge className="bg-primary text-primary-foreground">
              {numberOfNights} night{numberOfNights > 1 ? "s" : ""}
            </Badge>
          </div>

          <Separator />

          <div className="flex justify-between items-center">
            <span className="font-semibold">Total:</span>
            <span className="text-xl font-bold text-accent">GHC {totalPrice.toFixed(2)}</span>
          </div>
        </CardContent>
      </Card>

      {/* Terms & Conditions */}
      <Card className="border-border bg-muted/30">
        <CardContent className="pt-6">
          <p className="text-xs text-muted-foreground leading-relaxed">By confirming this booking, you agree that:</p>
          <ul className="text-xs text-muted-foreground list-disc list-inside mt-2 space-y-1">
            <li>Your payment will be processed immediately</li>
            <li>Funds are held in escrow until check-in verification</li>
            <li>Cancellations are subject to a 6% cancellation fee</li>
            <li>You must contact the provider 24 hours before check-out</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
