"use client"

import type { User } from "@supabase/supabase-js"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

export default function RenterNav({ user }: { user: User }) {
  const supabase = createClient()
  const router = useRouter()
  const fullName = user.user_metadata?.full_name || user.email

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  return (
    <header className="bg-primary text-primary-foreground shadow-lg sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/renter" className="flex items-center gap-2">
          <Image src="/logo.png" alt="RENTOgh Logo" width={40} height={40} className="rounded-lg" />
          <span className="text-2xl font-bold">RENTOgh</span>
        </Link>

        <div className="flex items-center gap-4">
          <Link href="/renter">
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
              Explore
            </Button>
          </Link>

          <Link href="/renter/bookings">
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
              My Bookings
            </Button>
          </Link>

          <Link href="/renter/wallet">
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
              Wallet
            </Button>
          </Link>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
                {fullName}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem asChild>
                <Link href="/renter/profile">Profile</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/renter/settings">Settings</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/renter/reviews">Reviews</Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </nav>
    </header>
  )
}
