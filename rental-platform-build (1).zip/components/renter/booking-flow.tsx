"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import RenterNav from "./renter-nav"
import BookingStep1 from "./booking-steps/booking-step1"
import BookingStep2 from "./booking-steps/booking-step2"
import BookingStep3 from "./booking-steps/booking-step3"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

interface Room {
  id: string
  room_type: string
  price_per_night: number
}

interface Property {
  id: string
  name: string
  provider_id: string
}

interface Wallet {
  id: string
  balance: number
}

export default function BookingFlow({
  room,
  property,
  wallet,
  userId,
}: {
  room: Room
  property: Property
  wallet: Wallet
  userId: string
}) {
  const [step, setStep] = useState(1)
  const [checkInDate, setCheckInDate] = useState<Date | null>(null)
  const [checkOutDate, setCheckOutDate] = useState<Date | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClient()

  const numberOfNights =
    checkInDate && checkOutDate
      ? Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24))
      : 0

  const basePrice = numberOfNights * room.price_per_night
  // Calculate commission based on property type: hotel 15%, hostel/apartment 10%
  const commissionRate = property.property_type === "hotel" ? 0.15 : 0.1
  const commissionAmount = basePrice * commissionRate
  const totalPrice = basePrice + commissionAmount

  const canProceedToPayment = checkInDate && checkOutDate && numberOfNights > 0 && totalPrice <= wallet.balance

  const handleCreateBooking = async () => {
    if (!checkInDate || !checkOutDate || numberOfNights <= 0) {
      toast({
        title: "Invalid dates",
        description: "Please select valid check-in and check-out dates",
        variant: "destructive",
      })
      return
    }

    if (totalPrice > wallet.balance) {
      toast({
        title: "Insufficient funds",
        description: `You need GHC ${totalPrice.toFixed(2)} but only have GHC ${wallet.balance.toFixed(2)}`,
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const { data: booking, error: bookingError } = await supabase
        .from("bookings")
        .insert({
          renter_id: userId,
          room_id: room.id,
          provider_id: property.provider_id,
          property_id: property.id,
          check_in_date: checkInDate.toISOString().split("T")[0],
          check_out_date: checkOutDate.toISOString().split("T")[0],
          number_of_nights: numberOfNights,
          base_price: basePrice,
          commission_amount: commissionAmount,
          total_price: totalPrice,
          booking_status: "pending",
          payment_status: "pending",
        })
        .select()
        .single()

      if (bookingError) throw bookingError

      const { error: walletUpdateError } = await supabase
        .from("wallets")
        .update({
          balance: wallet.balance - totalPrice,
          total_spent: (wallet.total_spent || 0) + totalPrice,
        })
        .eq("id", wallet.id)

      if (walletUpdateError) throw walletUpdateError

      await supabase.from("wallet_transactions").insert({
        wallet_id: wallet.id,
        transaction_type: "debit",
        amount: totalPrice,
        description: `Booking for ${property.name}`,
        reference_id: booking.id,
      })

      await supabase.from("provider_earnings").insert({
        provider_id: property.provider_id,
        booking_id: booking.id,
        base_amount: basePrice,
        commission_amount: commissionAmount,
        net_earnings: basePrice,
        status: "pending",
      })

      toast({
        title: "Success",
        description: "Booking created successfully",
      })

      router.push(`/renter/booking/${booking.id}/confirmation`)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create booking",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <RenterNav user={{ user_metadata: {} } as any} />

      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            {[1, 2, 3].map((stepNum) => (
              <div key={stepNum} className="flex flex-col items-center flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold mb-2 transition-colors ${
                    stepNum <= step ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {stepNum}
                </div>
                <span className="text-sm font-medium text-center">
                  {stepNum === 1 && "Select Dates"}
                  {stepNum === 2 && "Review Details"}
                  {stepNum === 3 && "Confirm Payment"}
                </span>
              </div>
            ))}
          </div>
          <div className="h-1 bg-muted rounded-full">
            <div
              className="h-1 bg-primary rounded-full transition-all"
              style={{ width: `${((step - 1) / 2) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content */}
        <Card className="border-border">
          <CardContent className="pt-6">
            {step === 1 && (
              <BookingStep1
                checkInDate={checkInDate}
                checkOutDate={checkOutDate}
                onCheckInChange={setCheckInDate}
                onCheckOutChange={setCheckOutDate}
                room={room}
                property={property}
              />
            )}

            {step === 2 && (
              <BookingStep2
                checkInDate={checkInDate}
                checkOutDate={checkOutDate}
                numberOfNights={numberOfNights}
                basePrice={basePrice}
                commissionAmount={commissionAmount}
                totalPrice={totalPrice}
                room={room}
                property={property}
              />
            )}

            {step === 3 && (
              <BookingStep3
                wallet={wallet}
                totalPrice={totalPrice}
                checkInDate={checkInDate}
                checkOutDate={checkOutDate}
                numberOfNights={numberOfNights}
                room={room}
                property={property}
              />
            )}
          </CardContent>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex gap-4 justify-between mt-8">
          <Link href="/renter">
            <Button variant="outline">Cancel</Button>
          </Link>

          <div className="flex gap-4">
            {step > 1 && (
              <Button variant="outline" onClick={() => setStep(step - 1)}>
                Back
              </Button>
            )}

            {step < 3 && (
              <Button
                className="bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => {
                  if (step === 1 && (!checkInDate || !checkOutDate || numberOfNights <= 0)) {
                    toast({
                      title: "Invalid dates",
                      description: "Please select valid dates",
                      variant: "destructive",
                    })
                    return
                  }
                  setStep(step + 1)
                }}
              >
                Next
              </Button>
            )}

            {step === 3 && (
              <Button
                className="bg-accent text-accent-foreground hover:bg-accent/90"
                onClick={handleCreateBooking}
                disabled={isLoading || !canProceedToPayment}
              >
                {isLoading ? "Processing..." : `Confirm Booking - GHC ${totalPrice.toFixed(2)}`}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
