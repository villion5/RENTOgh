"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { createClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"

interface Wallet {
  id: string
  balance: number
  total_funded: number
  total_spent: number
}

interface Transaction {
  id: string
  transaction_type: string
  amount: number
  description: string
  transaction_date: string
}

export default function WalletClient({
  wallet,
  transactions,
  userId,
}: {
  wallet: Wallet
  transactions: Transaction[]
  userId: string
}) {
  const [isOpen, setIsOpen] = useState(false)
  const [fundAmount, setFundAmount] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()
  const { toast } = useToast()

  const handleFundWallet = async (e: React.FormEvent) => {
    e.preventDefault()
    const amount = Number.parseFloat(fundAmount)

    if (!amount || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      // Update wallet balance
      const { error: updateError } = await supabase
        .from("wallets")
        .update({
          balance: wallet.balance + amount,
          total_funded: wallet.total_funded + amount,
        })
        .eq("id", wallet.id)

      if (updateError) throw updateError

      // Log transaction
      await supabase.from("wallet_transactions").insert({
        wallet_id: wallet.id,
        transaction_type: "credit",
        amount,
        description: "Wallet funding",
      })

      toast({
        title: "Success",
        description: `Successfully funded GHC ${amount.toFixed(2)} to your wallet`,
      })

      setFundAmount("")
      setIsOpen(false)
      window.location.reload()
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fund wallet",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Wallet Balance Card */}
      <Card className="border-border bg-gradient-to-r from-primary/10 to-accent/10">
        <CardHeader>
          <CardTitle>Wallet Balance</CardTitle>
          <CardDescription>Your current available funds</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-5xl font-bold text-primary">GHC {wallet.balance.toFixed(2)}</p>
              <p className="text-sm text-muted-foreground mt-2">
                Total Funded: GHC {wallet.total_funded.toFixed(2)} • Total Spent: GHC {wallet.total_spent.toFixed(2)}
              </p>
            </div>
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button className="bg-accent text-accent-foreground hover:bg-accent/90">Add Funds</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Fund Your Wallet</DialogTitle>
                  <DialogDescription>Add money to your wallet to make bookings</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleFundWallet} className="space-y-4">
                  <div className="grid gap-2">
                    <Label htmlFor="amount">Amount (GHC)</Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      placeholder="100.00"
                      value={fundAmount}
                      onChange={(e) => setFundAmount(e.target.value)}
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                    disabled={isLoading}
                  >
                    {isLoading ? "Processing..." : "Fund Wallet"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Recent Transactions */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>Last 10 transactions on your wallet</CardDescription>
        </CardHeader>
        <CardContent>
          {transactions.length > 0 ? (
            <div className="space-y-3">
              {transactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between py-3 border-b border-border last:border-0"
                >
                  <div className="flex-1">
                    <p className="font-semibold capitalize">
                      {transaction.description || transaction.transaction_type}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(transaction.transaction_date).toLocaleDateString()}{" "}
                      {new Date(transaction.transaction_date).toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge variant={transaction.transaction_type === "credit" ? "default" : "destructive"}>
                      {transaction.transaction_type === "credit" ? "+" : "-"}
                      {transaction.amount.toFixed(2)}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">No transactions yet</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
