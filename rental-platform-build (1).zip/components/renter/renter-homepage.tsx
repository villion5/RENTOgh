"use client"

import type { User } from "@supabase/supabase-js"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { createClient } from "@/lib/supabase/client"
import Link from "next/link"
import RenterNav from "./renter-nav"

interface Property {
  id: string
  name: string
  property_type: string
  location: string
  city: string
  rating: number
  review_count: number
  images_urls?: string[]
  amenities?: string[]
  is_verified: boolean
}

export default function RenterHomepage({ user }: { user: User }) {
  const [properties, setProperties] = useState<Property[]>([])
  const [filteredProperties, setFilteredProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState<string | null>("all")
  const [selectedCity, setSelectedCity] = useState<string | null>("all")
  const [sortBy, setSortBy] = useState("rating")

  const supabase = createClient()

  useEffect(() => {
    const fetchProperties = async () => {
      try {
        setLoading(true)
        const { data, error } = await supabase
          .from("properties")
          .select("*")
          .eq("is_verified", true)
          .order("rating", { ascending: false })
          .limit(50)

        if (error) throw error
        setProperties(data || [])
        setFilteredProperties(data || [])
      } catch (err) {
        console.error("Failed to fetch properties:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchProperties()
  }, [supabase])

  useEffect(() => {
    let filtered = properties

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.city.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Type filter
    if (selectedType !== "all") {
      filtered = filtered.filter((p) => p.property_type === selectedType)
    }

    // City filter
    if (selectedCity !== "all") {
      filtered = filtered.filter((p) => p.city === selectedCity)
    }

    // Sort
    if (sortBy === "rating") {
      filtered.sort((a, b) => b.rating - a.rating)
    } else if (sortBy === "newest") {
      filtered.sort((a, b) => new Date(b.id).getTime() - new Date(a.id).getTime())
    }

    setFilteredProperties(filtered)
  }, [searchQuery, selectedType, selectedCity, sortBy, properties])

  const cities = [...new Set(properties.map((p) => p.city))].filter(Boolean)

  return (
    <div className="min-h-screen bg-background text-foreground">
      <RenterNav user={user} />

      {/* Hero Search Section */}
      <section className="bg-gradient-to-r from-primary via-primary/90 to-primary/80 text-primary-foreground py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">Find Your Perfect Stay</h1>
          <p className="text-lg opacity-90 mb-6">Browse verified properties, hostels, hotels, and apartments</p>

          {/* Search Bar */}
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
            <Input
              placeholder="Search by location, property name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-white/90 text-foreground placeholder:text-muted-foreground mb-4"
            />

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Select value={selectedType || "all"} onValueChange={(val) => setSelectedType(val || "all")}>
                <SelectTrigger className="bg-white/90">
                  <SelectValue placeholder="Property Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="hotel">Hotel</SelectItem>
                  <SelectItem value="hostel">Hostel</SelectItem>
                  <SelectItem value="apartment">Apartment</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedCity || "all"} onValueChange={(val) => setSelectedCity(val || "all")}>
                <SelectTrigger className="bg-white/90">
                  <SelectValue placeholder="City" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  {cities.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="bg-white/90">
                  <SelectValue placeholder="Sort By" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rating">Top Rated</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                </SelectContent>
              </Select>

              <Button
                onClick={() => {
                  setSearchQuery("")
                  setSelectedType("all")
                  setSelectedCity("all")
                }}
                variant="outline"
                className="border-white/30 text-primary-foreground hover:bg-white/10"
              >
                Clear Filters
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section className="py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold">{filteredProperties.length} Properties Found</h2>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="h-48 bg-muted rounded-t-lg"></div>
                  <CardContent className="pt-4">
                    <div className="h-4 bg-muted rounded mb-2"></div>
                    <div className="h-4 bg-muted rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredProperties.length === 0 ? (
            <Card className="border-border">
              <CardContent className="pt-12 pb-12 text-center">
                <p className="text-lg text-muted-foreground mb-4">No properties found matching your search</p>
                <Button
                  onClick={() => {
                    setSearchQuery("")
                    setSelectedType("all")
                    setSelectedCity("all")
                  }}
                  variant="outline"
                >
                  Clear Filters
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProperties.map((property) => (
                <Link key={property.id} href={`/renter/property/${property.id}`}>
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer overflow-hidden group border-border">
                    <div className="relative h-48 bg-muted overflow-hidden">
                      {property.images_urls?.[0] ? (
                        <img
                          src={property.images_urls[0] || "/placeholder.svg"}
                          alt={property.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/10 to-accent/10">
                          <span className="text-4xl">🏠</span>
                        </div>
                      )}
                      {property.is_verified && (
                        <Badge className="absolute top-3 right-3 bg-accent text-accent-foreground">Verified</Badge>
                      )}
                    </div>

                    <CardContent className="pt-4">
                      <h3 className="font-bold text-lg mb-1 line-clamp-2">{property.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-1">{property.location}</p>

                      {/* Property Type Badge */}
                      <div className="mb-3">
                        <Badge variant="outline" className="capitalize">
                          {property.property_type}
                        </Badge>
                      </div>

                      {/* Rating */}
                      <div className="flex items-center gap-1 mb-3">
                        <span className="text-accent">★</span>
                        <span className="font-semibold">{property.rating ? property.rating.toFixed(1) : "New"}</span>
                        <span className="text-xs text-muted-foreground">({property.review_count} reviews)</span>
                      </div>

                      {/* Amenities */}
                      {property.amenities && property.amenities.length > 0 && (
                        <div className="flex gap-1 flex-wrap">
                          {property.amenities.slice(0, 3).map((amenity, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {amenity}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
