"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

interface Room {
  id: string
  room_type: string
  price_per_night: number
  is_available: boolean
  capacity: number
  features: string[]
}

interface Property {
  id: string
  name: string
  description: string
  property_type: string
  location: string
  city: string
  address: string
  rating: number
  review_count: number
  images_urls: string[]
  amenities: string[]
  is_verified: boolean
  rooms: Room[]
  provider_id: string
}

export default function PropertyDetails({
  property,
  userId,
}: {
  property: Property
  userId: string
}) {
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null)

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Back Button */}
        <Link href="/renter">
          <Button variant="outline" className="mb-6 bg-transparent">
            ← Back to Search
          </Button>
        </Link>

        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-4xl font-bold mb-2">{property.name}</h1>
            <p className="text-lg text-muted-foreground">{property.location}</p>
          </div>
          {property.is_verified && <Badge className="bg-accent text-accent-foreground">Verified Property</Badge>}
        </div>

        {/* Property Images */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {property.images_urls && property.images_urls.length > 0 ? (
            <>
              <div className="md:col-span-2 h-96 bg-muted rounded-lg overflow-hidden">
                <img
                  src={property.images_urls[0] || "/placeholder.svg"}
                  alt={property.name}
                  className="w-full h-full object-cover"
                />
              </div>
              {property.images_urls.slice(1, 3).map((img, idx) => (
                <div key={idx} className="h-48 bg-muted rounded-lg overflow-hidden">
                  <img
                    src={img || "/placeholder.svg"}
                    alt={`Property ${idx + 2}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </>
          ) : (
            <div className="md:col-span-2 h-96 bg-gradient-to-br from-primary/10 to-accent/10 rounded-lg flex items-center justify-center">
              <span className="text-6xl">🏠</span>
            </div>
          )}
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            {/* Property Info Card */}
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Property Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Property Type</p>
                    <p className="font-semibold capitalize">{property.property_type}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Rating</p>
                    <p className="font-semibold flex items-center gap-1">
                      <span className="text-accent">★</span>
                      {property.rating ? property.rating.toFixed(1) : "New"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Reviews</p>
                    <p className="font-semibold">{property.review_count}</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <p className="text-sm text-muted-foreground mb-2">Address</p>
                  <p className="font-semibold">{property.address || property.location}</p>
                  <p className="text-sm text-muted-foreground">{property.city}</p>
                </div>

                <Separator />

                <div>
                  <p className="text-sm text-muted-foreground mb-2">Description</p>
                  <p className="leading-relaxed">{property.description}</p>
                </div>

                {property.amenities && property.amenities.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <p className="text-sm text-muted-foreground mb-3">Amenities</p>
                      <div className="flex flex-wrap gap-2">
                        {property.amenities.map((amenity, idx) => (
                          <Badge key={idx} variant="secondary">
                            {amenity}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Available Rooms */}
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Available Rooms</CardTitle>
                <CardDescription>
                  {property.rooms?.filter((r) => r.is_available).length || 0} rooms available
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {property.rooms && property.rooms.length > 0 ? (
                    property.rooms.map((room) => (
                      <div
                        key={room.id}
                        className="border border-border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => setSelectedRoom(room)}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h4 className="font-semibold capitalize">{room.room_type}</h4>
                            <p className="text-sm text-muted-foreground">
                              Capacity: {room.capacity} person{room.capacity > 1 ? "s" : ""}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-accent">GHC {room.price_per_night.toFixed(2)}</p>
                            <p className="text-xs text-muted-foreground">per night</p>
                          </div>
                        </div>
                        {room.features && room.features.length > 0 && (
                          <div className="flex gap-1 flex-wrap mt-2">
                            {room.features.map((feature, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {feature}
                              </Badge>
                            ))}
                          </div>
                        )}
                        {!room.is_available && (
                          <Badge variant="destructive" className="mt-2">
                            Not Available
                          </Badge>
                        )}
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground">No rooms available</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Booking Card */}
          <div>
            {selectedRoom ? (
              <Card className="border-border sticky top-24 bg-accent/5">
                <CardHeader>
                  <CardTitle>Book Room</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Room Type</p>
                    <p className="font-semibold capitalize">{selectedRoom.room_type}</p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground">Price per Night</p>
                    <p className="text-2xl font-bold text-accent">GHC {selectedRoom.price_per_night.toFixed(2)}</p>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Capacity</p>
                    <p className="font-semibold">
                      {selectedRoom.capacity} person{selectedRoom.capacity > 1 ? "s" : ""}
                    </p>
                  </div>

                  <Link href={`/renter/booking/new?room=${selectedRoom.id}&property=${property.id}`}>
                    <Button
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                      disabled={!selectedRoom.is_available}
                    >
                      {selectedRoom.is_available ? "Book Now" : "Not Available"}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-border">
                <CardContent className="pt-6 text-center">
                  <p className="text-muted-foreground">Select a room to see booking details</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
