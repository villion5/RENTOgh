"use client"

import type { User } from "@supabase/supabase-js"
import AdminNav from "./admin-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Users, Home, CheckCircle2, TrendingUp, AlertCircle } from "lucide-react"

interface UnverifiedProvider {
  id: string
  business_name: string
  created_at: string
  is_verified: boolean
}

export default function AdminDashboard({
  user,
  totalUsers,
  totalProviders,
  verifiedProviders,
  totalBookings,
  totalRevenue,
  unverifiedProviders,
}: {
  user: User
  totalUsers: number
  totalProviders: number
  verifiedProviders: number
  totalBookings: number
  totalRevenue: number
  unverifiedProviders: UnverifiedProvider[]
}) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <AdminNav user={user} />

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage platform operations, verify providers, and monitor metrics</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Total Users</span>
                <Users className="w-4 h-4 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{totalUsers}</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Providers</span>
                <Home className="w-4 h-4 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{totalProviders}</p>
              <p className="text-xs text-muted-foreground mt-1">{verifiedProviders} verified</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Bookings</span>
                <CheckCircle2 className="w-4 h-4 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{totalBookings}</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Total Revenue</span>
                <TrendingUp className="w-4 h-4 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">GHC {totalRevenue.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground mt-1">Commission collected</p>
            </CardContent>
          </Card>

          <Card className="border-destructive bg-destructive/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Pending Verification</span>
                <AlertCircle className="w-4 h-4 text-destructive" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{unverifiedProviders.length}</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="verification" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="verification">Provider Verification</TabsTrigger>
            <TabsTrigger value="providers">All Providers</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          {/* Verification Tab */}
          <TabsContent value="verification" className="space-y-4">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Pending Verification Requests</CardTitle>
                <CardDescription>Review and approve provider registration documents</CardDescription>
              </CardHeader>
              <CardContent>
                {unverifiedProviders.length > 0 ? (
                  <div className="space-y-3">
                    {unverifiedProviders.map((provider) => (
                      <div
                        key={provider.id}
                        className="border border-border rounded-lg p-4 flex items-center justify-between hover:shadow-sm transition-shadow"
                      >
                        <div className="flex-1">
                          <h4 className="font-semibold">{provider.business_name}</h4>
                          <p className="text-xs text-muted-foreground">
                            Applied: {new Date(provider.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <Link href={`/admin/verification/${provider.id}`}>
                          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Review</Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">No pending verifications</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Providers Tab */}
          <TabsContent value="providers" className="space-y-4">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>All Providers</CardTitle>
                <CardDescription>View and manage all registered providers</CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/admin/providers">
                  <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                    View All Providers
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-4">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Platform Analytics</CardTitle>
                <CardDescription>View detailed reports and metrics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href="/admin/reports/revenue">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    Revenue Reports
                  </Button>
                </Link>
                <Link href="/admin/reports/bookings">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    Booking Analytics
                  </Button>
                </Link>
                <Link href="/admin/reports/users">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    User Statistics
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
