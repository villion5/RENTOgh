"use client"

import type { User } from "@supabase/supabase-js"
import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import SubAdminNav from "./sub-admin-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, XCircle, AlertCircle } from "lucide-react"

interface Provider {
  id: string
  business_name: string
  contact_person_name: string
  email: string
  phone_number: string
  property_type: string
  registration_document_url?: string
  ownership_document_url?: string
  created_at: string
}

interface Profile {
  full_name: string
  email: string
}

export default function SubAdminVerificationReview({
  provider,
  profile,
  user,
}: {
  provider: Provider
  profile: Profile
  user: User
}) {
  const [rejectionReason, setRejectionReason] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()
  const router = useRouter()
  const { toast } = useToast()

  const handleApprove = async () => {
    setIsLoading(true)
    try {
      const { error } = await supabase
        .from("providers")
        .update({
          is_verified: true,
          verification_date: new Date().toISOString(),
          subscription_status: "pending",
        })
        .eq("id", provider.id)

      if (error) throw error

      toast({
        title: "Success",
        description: "Provider verified for compliance",
      })

      router.push("/sub-admin/dashboard")
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to verify provider",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleReject = async () => {
    if (!rejectionReason.trim()) {
      toast({
        title: "Error",
        description: "Please provide a reason for rejection",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      toast({
        title: "Success",
        description: "Provider verification rejected",
      })

      router.push("/sub-admin/dashboard")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to reject provider",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SubAdminNav user={user} />

      <div className="max-w-2xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Provider Compliance Review</h1>
          <p className="text-muted-foreground">Verify provider compliance with rental regulations</p>
        </div>

        {/* Provider Information */}
        <Card className="border-border mb-6">
          <CardHeader>
            <CardTitle>{provider.business_name}</CardTitle>
            <CardDescription>
              Application submitted {new Date(provider.created_at).toLocaleDateString()}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Contact Person</p>
                <p className="font-semibold">{provider.contact_person_name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Property Type</p>
                <p className="font-semibold capitalize">{provider.property_type}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="font-semibold">{provider.email}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Phone</p>
                <p className="font-semibold">{provider.phone_number}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Compliance Documents */}
        <Card className="border-border mb-6">
          <CardHeader>
            <CardTitle>Compliance Documentation</CardTitle>
            <CardDescription>Review submitted regulatory documents</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="border border-border rounded-lg p-4">
              <p className="text-sm text-muted-foreground mb-2">Registration Document</p>
              {provider.registration_document_url ? (
                <a
                  href={provider.registration_document_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:underline text-sm font-medium"
                >
                  View Document →
                </a>
              ) : (
                <Badge variant="destructive">Not provided</Badge>
              )}
            </div>

            <div className="border border-border rounded-lg p-4">
              <p className="text-sm text-muted-foreground mb-2">License/Ownership Document</p>
              {provider.ownership_document_url ? (
                <a
                  href={provider.ownership_document_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:underline text-sm font-medium"
                >
                  View Document →
                </a>
              ) : (
                <Badge variant="destructive">Not provided</Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Compliance Decision */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle>Compliance Decision</CardTitle>
            <CardDescription>Approve or reject provider for rental market operation</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-accent/10 border border-accent rounded-lg p-4 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm mb-2">Approve for Compliance</p>
                <p className="text-xs text-muted-foreground">
                  Provider will be verified and allowed to operate rental properties on the platform.
                </p>
              </div>
            </div>

            <div className="bg-destructive/10 border border-destructive rounded-lg p-4 flex items-start gap-3">
              <XCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm mb-2">Reject Application</p>
                <p className="text-xs text-muted-foreground">
                  Provider will be notified of non-compliance and must reapply with corrected documentation.
                </p>
              </div>
            </div>

            <div className="bg-blue-500/10 border border-blue-500 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm mb-2">Compliance Note</p>
                <p className="text-xs text-muted-foreground">
                  No financial, commission, or monetary data is visible in this interface. Verification is based on
                  compliance documentation only.
                </p>
              </div>
            </div>

            <div className="grid gap-2">
              <p className="text-sm font-medium">Rejection Reason (if applicable)</p>
              <Textarea
                placeholder="Specify compliance issues or reasons for rejection..."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={4}
              />
            </div>

            <div className="flex gap-4">
              <Button variant="outline" onClick={() => router.back()} className="flex-1">
                Back
              </Button>
              <Button variant="outline" onClick={handleReject} disabled={isLoading} className="flex-1 bg-transparent">
                Reject
              </Button>
              <Button
                className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90"
                onClick={handleApprove}
                disabled={isLoading}
              >
                {isLoading ? "Processing..." : "Approve"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
