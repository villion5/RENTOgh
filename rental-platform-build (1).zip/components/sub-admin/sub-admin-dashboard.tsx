"use client"

import type { User } from "@supabase/supabase-js"
import SubAdminNav from "./sub-admin-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Users, CheckCircle2, AlertCircle, Shield } from "lucide-react"

interface UnverifiedProvider {
  id: string
  business_name: string
  created_at: string
  is_verified: boolean
  property_type: string
}

export default function SubAdminDashboard({
  user,
  totalProviders,
  verifiedProviders,
  unverifiedProviders,
}: {
  user: User
  totalProviders: number
  verifiedProviders: number
  unverifiedProviders: UnverifiedProvider[]
}) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SubAdminNav user={user} />

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-8 h-8 text-accent" />
            <h1 className="text-3xl font-bold">Rent Control Office Dashboard</h1>
          </div>
          <p className="text-muted-foreground">Provider verification and compliance oversight</p>
        </div>

        {/* KPI Cards - Verification Metrics Only */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Total Providers</span>
                <Users className="w-4 h-4 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{totalProviders}</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Verified Providers</span>
                <CheckCircle2 className="w-4 h-4 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{verifiedProviders}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {totalProviders > 0 ? `${Math.round((verifiedProviders / totalProviders) * 100)}%` : "0%"} verified
              </p>
            </CardContent>
          </Card>

          <Card className="border-destructive bg-destructive/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Pending Verification</span>
                <AlertCircle className="w-4 h-4 text-destructive" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{unverifiedProviders.length}</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="verification" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="verification">Provider Verification</TabsTrigger>
            <TabsTrigger value="all-providers">All Providers</TabsTrigger>
          </TabsList>

          {/* Verification Tab */}
          <TabsContent value="verification" className="space-y-4">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Pending Verification Requests</CardTitle>
                <CardDescription>Review and verify provider compliance with rental regulations</CardDescription>
              </CardHeader>
              <CardContent>
                {unverifiedProviders.length > 0 ? (
                  <div className="space-y-3">
                    {unverifiedProviders.map((provider) => (
                      <div
                        key={provider.id}
                        className="border border-border rounded-lg p-4 flex items-center justify-between hover:shadow-sm transition-shadow"
                      >
                        <div className="flex-1">
                          <h4 className="font-semibold">{provider.business_name}</h4>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                            <span>{provider.property_type}</span>
                            <span>•</span>
                            <span>Applied: {new Date(provider.created_at).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <Link href={`/sub-admin/verification/${provider.id}`}>
                          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Review</Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">No pending verifications</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* All Providers Tab */}
          <TabsContent value="all-providers" className="space-y-4">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Verified Providers</CardTitle>
                <CardDescription>View all providers verified for compliance</CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/sub-admin/providers">
                  <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                    View All Providers
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Info Banner */}
        <div className="mt-8 bg-accent/10 border border-accent rounded-lg p-6">
          <h3 className="font-semibold mb-2 flex items-center gap-2">
            <Shield className="w-4 h-4" />
            Rent Control Office Oversight
          </h3>
          <p className="text-sm text-muted-foreground">
            This dashboard is designed for Ghana Rent Control Office to verify provider compliance with rental
            regulations. Access is limited to provider verification and compliance data only.
          </p>
        </div>
      </div>
    </div>
  )
}
