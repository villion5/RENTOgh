"use client"

import type { User } from "@supabase/supabase-js"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Shield } from "lucide-react"

export default function SubAdminNav({ user }: { user: User }) {
  const supabase = createClient()
  const router = useRouter()

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  return (
    <header className="bg-primary text-primary-foreground shadow-lg sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/sub-admin/dashboard" className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-primary-foreground/20 px-3 py-2 rounded-lg">
            <Shield className="w-5 h-5" />
            <span className="text-sm font-bold">Rent Control</span>
          </div>
          <span className="text-xl font-bold hidden sm:inline">Ghana RCO</span>
        </Link>

        <div className="flex items-center gap-4">
          <Link href="/sub-admin/dashboard">
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
              Dashboard
            </Button>
          </Link>

          <Link href="/sub-admin/verification">
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
              Verification
            </Button>
          </Link>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-primary-foreground hover:bg-primary/80">
                Menu
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem asChild>
                <Link href="/sub-admin/profile">Profile</Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </nav>
    </header>
  )
}
