"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Heart, MessageCircle, Trash2, Edit2 } from "lucide-react"

interface Post {
  id: string
  title: string
  content: string
  likes_count: number
  comments_count: number
  is_published: boolean
  created_at: string
  properties?: { name: string }
}

export default function ProviderPostsList({ posts }: { posts: Post[] }) {
  const supabase = createClient()
  const router = useRouter()
  const { toast } = useToast()
  const [isDeleting, setIsDeleting] = useState<string | null>(null)

  const handleDeletePost = async (postId: string) => {
    if (!confirm("Are you sure you want to delete this post?")) return

    setIsDeleting(postId)
    try {
      const { error } = await supabase.from("provider_posts").delete().eq("id", postId)

      if (error) throw error

      toast({
        title: "Success",
        description: "Post deleted successfully",
      })

      router.refresh()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete post",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(null)
    }
  }

  if (posts.length === 0) {
    return (
      <Card className="border-border">
        <CardContent className="pt-12 pb-12 text-center">
          <p className="text-muted-foreground mb-4">No posts yet</p>
          <Link href="/provider/posts/new">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Create Your First Post</Button>
          </Link>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {posts.map((post) => (
        <Card key={post.id} className="border-border hover:shadow-md transition-shadow">
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <CardTitle className="text-lg mb-1">{post.title}</CardTitle>
                {post.properties && <p className="text-sm text-muted-foreground">{post.properties.name}</p>}
              </div>
              <Badge className={post.is_published ? "bg-accent text-accent-foreground" : ""}>
                {post.is_published ? "Published" : "Draft"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4 line-clamp-2">{post.content}</p>

            <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
              <div className="flex gap-4">
                <span className="flex items-center gap-1">
                  <Heart className="w-4 h-4" /> {post.likes_count}
                </span>
                <span className="flex items-center gap-1">
                  <MessageCircle className="w-4 h-4" /> {post.comments_count}
                </span>
              </div>
              <span>{new Date(post.created_at).toLocaleDateString()}</span>
            </div>

            <div className="flex gap-2">
              <Link href={`/provider/posts/${post.id}/edit`} className="flex-1">
                <Button variant="outline" size="sm" className="w-full bg-transparent">
                  <Edit2 className="w-4 h-4 mr-2" /> Edit
                </Button>
              </Link>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleDeletePost(post.id)}
                disabled={isDeleting === post.id}
              >
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
