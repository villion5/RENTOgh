"use client"

import type { User } from "@supabase/supabase-js"
import ProviderNav from "./provider-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { TrendingUp, Home, Calendar, DollarSign } from "lucide-react"
import { format } from "date-fns"

interface Property {
  id: string
  name: string
  property_type: string
  location: string
  total_rooms: number
  occupied_rooms: number
  rating: number
  is_verified: boolean
}

interface Booking {
  id: string
  booking_status: string
  check_in_date: string
  check_out_date: string
  total_price: number
  properties: { name: string }
  rooms: { room_type: string }
}

interface Earnings {
  base_amount: number
  commission_amount: number
  net_earnings: number
  status: string
}

interface Provider {
  is_verified: boolean
  subscription_status: string
  subscription_expiry_date: string
  total_properties: number
  total_rooms: number
  average_rating: number
}

export default function ProviderDashboard({
  user,
  provider,
  properties,
  bookings,
  earnings,
}: {
  user: User
  provider: Provider
  properties: Property[]
  bookings: Booking[]
  earnings: Earnings[]
}) {
  const totalBookings = bookings.length
  const totalEarnings = earnings.reduce((sum, e) => sum + e.net_earnings, 0)
  const confirmedBookings = bookings.filter((b) => b.booking_status === "confirmed").length
  const totalRooms = properties.reduce((sum, p) => sum + p.total_rooms, 0)
  const occupiedRooms = properties.reduce((sum, p) => sum + p.occupied_rooms, 0)
  const occupancyRate = totalRooms > 0 ? ((occupiedRooms / totalRooms) * 100).toFixed(1) : 0

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProviderNav user={user} />

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Provider Dashboard</h1>
          <p className="text-muted-foreground">Manage your properties, bookings, and earnings</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Total Properties</span>
                <Home className="w-4 h-4 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{properties.length}</div>
              <p className="text-xs text-muted-foreground mt-1">{totalRooms} rooms total</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Bookings</span>
                <Calendar className="w-4 h-4 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{confirmedBookings}</div>
              <p className="text-xs text-muted-foreground mt-1">{totalBookings} total</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Total Earnings</span>
                <DollarSign className="w-4 h-4 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">GHC {totalEarnings.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground mt-1">Net revenue</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>Occupancy Rate</span>
                <TrendingUp className="w-4 h-4 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{occupancyRate}%</div>
              <p className="text-xs text-muted-foreground mt-1">
                {occupiedRooms}/{totalRooms} rooms occupied
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Verification Status */}
        {!provider?.is_verified && (
          <Card className="border-destructive bg-destructive/5 mb-8">
            <CardHeader>
              <CardTitle className="text-base flex items-center justify-between">
                <span>Verification Required</span>
                <Badge variant="destructive">Not Verified</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Your provider account needs verification. Upload your business documents for review by the sub-admin.
              </p>
              <Link href="/provider/settings/verification">
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                  Complete Verification
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Subscription Status */}
        {provider?.subscription_status !== "active" && (
          <Card className="border-accent bg-accent/5 mb-8">
            <CardHeader>
              <CardTitle className="text-base flex items-center justify-between">
                <span>Subscription Required</span>
                <Badge className="bg-accent text-accent-foreground">GHC 50/Year</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Activate your annual subscription to list properties and receive bookings.
              </p>
              <Link href="/provider/settings/subscription">
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                  Activate Subscription
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Main Content Tabs */}
        <Tabs defaultValue="properties" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="properties">Properties</TabsTrigger>
            <TabsTrigger value="bookings">Recent Bookings</TabsTrigger>
            <TabsTrigger value="earnings">Earnings</TabsTrigger>
          </TabsList>

          {/* Properties Tab */}
          <TabsContent value="properties" className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">My Properties</h3>
              <Link href="/provider/property/new">
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Add Property</Button>
              </Link>
            </div>

            {properties.length > 0 ? (
              <div className="grid gap-4">
                {properties.map((property) => (
                  <Card key={property.id} className="border-border hover:shadow-md transition-shadow">
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h4 className="font-bold text-lg">{property.name}</h4>
                          <p className="text-sm text-muted-foreground mb-2">{property.location}</p>
                          <div className="flex gap-2">
                            <Badge variant="outline" className="capitalize">
                              {property.property_type}
                            </Badge>
                            {property.is_verified && (
                              <Badge className="bg-accent text-accent-foreground">Verified</Badge>
                            )}
                          </div>
                        </div>
                        <Link href={`/provider/property/${property.id}/edit`}>
                          <Button variant="outline" size="sm">
                            Manage
                          </Button>
                        </Link>
                      </div>

                      <div className="grid grid-cols-4 gap-4 mt-4 pt-4 border-t border-border">
                        <div>
                          <p className="text-xs text-muted-foreground">Total Rooms</p>
                          <p className="text-lg font-bold">{property.total_rooms}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Occupied</p>
                          <p className="text-lg font-bold text-accent">{property.occupied_rooms}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Available</p>
                          <p className="text-lg font-bold">{property.total_rooms - property.occupied_rooms}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Rating</p>
                          <p className="text-lg font-bold">{property.rating ? property.rating.toFixed(1) : "New"}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-border">
                <CardContent className="pt-12 pb-12 text-center">
                  <p className="text-muted-foreground mb-4">No properties yet</p>
                  <Link href="/provider/property/new">
                    <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                      Create Your First Property
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Bookings Tab */}
          <TabsContent value="bookings" className="space-y-4">
            <h3 className="text-lg font-semibold">Recent Bookings</h3>

            {bookings.length > 0 ? (
              <div className="space-y-3">
                {bookings.map((booking) => (
                  <Card key={booking.id} className="border-border">
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h4 className="font-semibold">{booking.properties?.name}</h4>
                          <p className="text-sm text-muted-foreground capitalize">
                            {booking.rooms?.room_type} • {booking.booking_status}
                          </p>
                        </div>
                        <Badge
                          className={booking.booking_status === "confirmed" ? "bg-accent text-accent-foreground" : ""}
                        >
                          {booking.booking_status}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-4 gap-2 text-sm">
                        <div>
                          <p className="text-muted-foreground">Check-in</p>
                          <p className="font-medium">{format(new Date(booking.check_in_date), "MMM dd")}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Check-out</p>
                          <p className="font-medium">{format(new Date(booking.check_out_date), "MMM dd")}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Amount</p>
                          <p className="font-bold text-accent">GHC {booking.total_price.toFixed(2)}</p>
                        </div>
                        <div className="text-right">
                          <Link href={`/provider/booking/${booking.id}`}>
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-border">
                <CardContent className="pt-12 pb-12 text-center">
                  <p className="text-muted-foreground">No bookings yet</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Earnings Tab */}
          <TabsContent value="earnings" className="space-y-4">
            <h3 className="text-lg font-semibold">Earnings Summary</h3>

            <div className="grid grid-cols-3 gap-4 mb-6">
              <Card className="border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">Total Earnings</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-accent">GHC {totalEarnings.toFixed(2)}</p>
                </CardContent>
              </Card>

              <Card className="border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">Pending Payouts</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">
                    GHC{" "}
                    {earnings
                      .filter((e) => e.status === "pending")
                      .reduce((sum, e) => sum + e.net_earnings, 0)
                      .toFixed(2)}
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">Paid Out</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">
                    GHC{" "}
                    {earnings
                      .filter((e) => e.status === "paid")
                      .reduce((sum, e) => sum + e.net_earnings, 0)
                      .toFixed(2)}
                  </p>
                </CardContent>
              </Card>
            </div>

            <Link href="/provider/earnings">
              <Button variant="outline" className="w-full bg-transparent">
                View Detailed Earnings Report
              </Button>
            </Link>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
