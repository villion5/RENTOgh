"use client"

import type { User } from "@supabase/supabase-js"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check } from "lucide-react"

interface Plan {
  id: string
  name: string
  annual_fee: number
  benefits: string[]
}

interface Provider {
  subscription_status: string
  subscription_expiry_date: string
  annual_fee_paid: number
}

export default function SubscriptionManager({
  provider,
  plans,
  user,
}: {
  provider: Provider
  plans: Plan[]
  user: User
}) {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Subscription Plans</h1>
        <p className="text-muted-foreground">
          Activate your annual subscription to list properties and receive bookings
        </p>
      </div>

      {/* Current Status */}
      {provider?.subscription_status === "active" && (
        <Card className="border-accent bg-accent/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold">Active Subscription</p>
                <p className="text-sm text-muted-foreground">
                  Expires: {new Date(provider.subscription_expiry_date).toLocaleDateString()}
                </p>
              </div>
              <Badge className="bg-accent text-accent-foreground">Active</Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card key={plan.id} className="border-border hover:shadow-lg transition-shadow relative">
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <div className="mt-4">
                <p className="text-3xl font-bold text-accent">GHC {plan.annual_fee.toFixed(2)}</p>
                <p className="text-sm text-muted-foreground">per year</p>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                {plan.benefits.map((benefit, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{benefit}</span>
                  </div>
                ))}
              </div>

              <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                {provider?.subscription_status === "active" ? "Upgrade" : "Activate"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Important Notice */}
      <Card className="border-border bg-muted/30">
        <CardHeader>
          <CardTitle className="text-base">Important Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <p>
            Your subscription enables you to list properties and receive bookings. Without an active subscription, your
            account will be suspended.
          </p>
          <p>
            Subscriptions are billed annually. You will receive a reminder email 30 days before your subscription
            expires.
          </p>
          <p>All payments are non-refundable but can be applied toward future subscriptions.</p>
        </CardContent>
      </Card>
    </div>
  )
}
