"use client"

import type React from "react"

import type { User } from "@supabase/supabase-js"
import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import ProviderNav from "./provider-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Edit2, Trash2 } from "lucide-react"

interface Room {
  id: string
  room_type: string
  room_number: string
  price_per_night: number
  is_available: boolean
  capacity: number
  features: string[]
}

interface Property {
  id: string
  name: string
  total_rooms: number
}

export default function RoomManagement({
  property,
  rooms,
  user,
}: {
  property: Property
  rooms: Room[]
  user: User
}) {
  const [isOpen, setIsOpen] = useState(false)
  const [editingRoom, setEditingRoom] = useState<Room | null>(null)
  const [formData, setFormData] = useState({
    room_type: "single",
    room_number: "",
    price_per_night: "",
    capacity: "1",
    features: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()
  const router = useRouter()
  const { toast } = useToast()

  const handleOpenDialog = (room?: Room) => {
    if (room) {
      setEditingRoom(room)
      setFormData({
        room_type: room.room_type,
        room_number: room.room_number || "",
        price_per_night: room.price_per_night.toString(),
        capacity: room.capacity.toString(),
        features: room.features?.join(", ") || "",
      })
    } else {
      setEditingRoom(null)
      setFormData({
        room_type: "single",
        room_number: "",
        price_per_night: "",
        capacity: "1",
        features: "",
      })
    }
    setIsOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const features = formData.features
        .split(",")
        .map((f) => f.trim())
        .filter((f) => f)

      const data = {
        room_type: formData.room_type,
        room_number: formData.room_number,
        price_per_night: Number.parseFloat(formData.price_per_night),
        capacity: Number.parseInt(formData.capacity),
        features: features,
        is_available: true,
      }

      if (editingRoom) {
        const { error } = await supabase.from("rooms").update(data).eq("id", editingRoom.id)

        if (error) throw error

        toast({
          title: "Success",
          description: "Room updated successfully",
        })
      } else {
        const { error } = await supabase.from("rooms").insert({
          ...data,
          property_id: property.id,
          provider_id: user.id,
        })

        if (error) throw error

        toast({
          title: "Success",
          description: "Room added successfully",
        })
      }

      setIsOpen(false)
      router.refresh()
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save room",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteRoom = async (roomId: string) => {
    if (!confirm("Are you sure you want to delete this room?")) return

    try {
      const { error } = await supabase.from("rooms").delete().eq("id", roomId)

      if (error) throw error

      toast({
        title: "Success",
        description: "Room deleted successfully",
      })

      router.refresh()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete room",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProviderNav user={user} />

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Manage Rooms</h1>
            <p className="text-muted-foreground">{property.name}</p>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button
                className="bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => handleOpenDialog()}
              >
                Add Room
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>{editingRoom ? "Edit Room" : "Add New Room"}</DialogTitle>
                <DialogDescription>
                  {editingRoom ? "Update room details" : "Add a new room to your property"}
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="room_type">Room Type</Label>
                  <Select
                    value={formData.room_type}
                    onValueChange={(val) => setFormData((prev) => ({ ...prev, room_type: val }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="single">Single</SelectItem>
                      <SelectItem value="1br">1 Bedroom</SelectItem>
                      <SelectItem value="2br">2 Bedroom</SelectItem>
                      <SelectItem value="3br">3 Bedroom</SelectItem>
                      <SelectItem value="dorm_male">Dorm (Male)</SelectItem>
                      <SelectItem value="dorm_female">Dorm (Female)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="room_number">Room Number</Label>
                  <Input
                    id="room_number"
                    value={formData.room_number}
                    onChange={(e) => setFormData((prev) => ({ ...prev, room_number: e.target.value }))}
                    placeholder="e.g., 101"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="capacity">Capacity</Label>
                    <Select
                      value={formData.capacity}
                      onValueChange={(val) => setFormData((prev) => ({ ...prev, capacity: val }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5, 6].map((n) => (
                          <SelectItem key={n} value={n.toString()}>
                            {n} person{n > 1 ? "s" : ""}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="price">Price per Night (GHC)</Label>
                    <Input
                      id="price"
                      type="number"
                      step="0.01"
                      value={formData.price_per_night}
                      onChange={(e) => setFormData((prev) => ({ ...prev, price_per_night: e.target.value }))}
                      placeholder="0.00"
                      required
                    />
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="features">Features (comma-separated)</Label>
                  <Input
                    id="features"
                    value={formData.features}
                    onChange={(e) => setFormData((prev) => ({ ...prev, features: e.target.value }))}
                    placeholder="e.g., AC, WiFi, TV"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  disabled={isLoading}
                >
                  {isLoading ? "Saving..." : "Save Room"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {rooms.length > 0 ? (
          <div className="grid gap-4">
            {rooms.map((room) => (
              <Card key={room.id} className="border-border">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-bold capitalize">{room.room_type}</h3>
                        {room.room_number && <Badge variant="outline">#{room.room_number}</Badge>}
                        {room.is_available ? (
                          <Badge className="bg-accent text-accent-foreground">Available</Badge>
                        ) : (
                          <Badge variant="destructive">Occupied</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">
                        Capacity: {room.capacity} person{room.capacity > 1 ? "s" : ""} • GHC{" "}
                        {room.price_per_night.toFixed(2)}/night
                      </p>
                      {room.features && room.features.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {room.features.map((feature, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleOpenDialog(room)}>
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDeleteRoom(room.id)}>
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-border">
            <CardContent className="pt-12 pb-12 text-center">
              <p className="text-muted-foreground mb-4">No rooms added yet</p>
              <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogTrigger asChild>
                  <Button
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                    onClick={() => handleOpenDialog()}
                  >
                    Add First Room
                  </Button>
                </DialogTrigger>
              </Dialog>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
